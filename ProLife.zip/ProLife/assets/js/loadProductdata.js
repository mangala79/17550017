//google.charts.load('current', {packages:['corechart']});
//google.charts.setOnLoadCallback();

function load_summary_data(year)
{
    //alert('load_summary_data.js loaded');
    //alert (year);
    var temp_title = 'temp title' + ' ' + year;
    //var d = new Date();
    $.ajax("DashboardCon/fetchSummaryData",{
        method:"POST",
        data:{year:year},
        dataType:"JSON",      
        success:function(data)
        {
            console.log("success");
            //alert('JSON data success');
            drawRevDistributionChart(data, temp_title);
            drawSalesDistributionChart(data, temp_title);
            drawChurnImpactChart(data, temp_title);
            drawRevTargetAchievementChart(data, temp_title);

        },
        error: function(xhr,ajaxOptions, thrownError) {
        //alert('JSON data fail')
        alert("Data is not availabel. please check")
        //alert(xhr.status);
        //alert(thrownError);
        console.log("error");

      }
        })
    
}


function load_productwise_data(year,product)
{
    //alert('load_summary_data.js loaded');
    //alert (year);
    var temp_title = 'temp title' + ' ' + year;
    $.ajax("DashboardCon/fetchProductData",{
        method:"POST",
        data:{year:year,product:product},
        dataType:"JSON",      
        success:function(data)
        {
            console.log("success");
            //alert('JSON data success');
            drawProRevChart(data, temp_title);
            drawProSalesChart(data, temp_title);
            drawProChurnChart(data, temp_title);
            drawCxBaseChart(data, temp_title);
            
        },
        error: function(xhr,ajaxOptions, thrownError) {
        //alert('JSON data fail')
        alert("Data is not availabel. please check")
        alert(xhr.status);
        alert(thrownError);
        console.log("error");

      }
        })
    
}

