function drawProRevChart(chart_data, chart_main_title)
{
    var jsonData = chart_data;
    var data_revenue = new google.visualization.DataTable();
    data_revenue.addColumn('string', 'Month');
    data_revenue.addColumn('number', 'Actual Revenue');
    data_revenue.addColumn('number', 'Target Revenue');


    //alert('drawRevDistributionChart function loaded');

    $.each(jsonData, function(i, jsonData){
        var month = jsonData.month;
        var proRevenue = parseFloat($.trim(jsonData.proRevenue));
        var mRevTar = parseFloat($.trim(jsonData.mRevTar));
        data_revenue.addRows([[month,proRevenue,mRevTar]]);
    });


    var options = {
      //title:"Revenue"+ chart_main_title,
        hAxis: {
            title: "month"
        },
        vAxis: {
            title: 'Revenue Achievement'
        },
        chartArea:{width:'60%',height:'65%'}
    }

      var container = document.getElementById('chart1_area');
      container.style.display = null;
        var chart_revenue = new google.visualization.LineChart(container);
      chart_revenue.draw(data_revenue, options);
}

function drawProSalesChart(chart_data, chart_main_title)
{
    var jsonData = chart_data;
    var data_sales = new google.visualization.DataTable();
    data_sales.addColumn('string', 'Month');
    data_sales.addColumn('number', 'Actual Sales');
    data_sales.addColumn('number', 'Target Sales');


    //alert('drawRevDistributionChart function loaded');

    $.each(jsonData, function(i, jsonData){
        var month = jsonData.month;
        var mSales = parseFloat($.trim(jsonData.mSales));
        var mSalesTar = parseFloat($.trim(jsonData.mSalesTar));
        data_sales.addRows([[month,mSales,mSalesTar]]);
    });


    var options = {
      //title:"Revenue"+ chart_main_title,
        hAxis: {
            title: "month"
        },
        vAxis: {
            title: 'Sales Achievement'
        },
        chartArea:{width:'60%',height:'65%'}
    }

      var container = document.getElementById('chart2_area');
      container.style.display = null;
        var chart_sales = new google.visualization.LineChart(container);
      chart_sales.draw(data_sales, options);
}

function drawProChurnChart(chart_data, chart_main_title)
{
    var jsonData = chart_data;
    var data_discon = new google.visualization.DataTable();
    data_discon.addColumn('string', 'Month');
    data_discon.addColumn('number', 'Actual Churn ');
    data_discon.addColumn('number', 'Forecasted Churn ');


    //alert('drawProChurnChart function loaded');

    $.each(jsonData, function(i, jsonData){
        var month = jsonData.month;
        var mDis = parseFloat($.trim(jsonData.mDis));
        var mDisTar = parseFloat($.trim(jsonData.mDisTar));
        data_discon.addRows([[month,mDis,mDisTar]]);
    });


    var options = {
      //title:"Revenue"+ chart_main_title,
        hAxis: {
            title: "month"
        },
        vAxis: {
            title: 'Customer churn'
        },
        chartArea:{width:'60%',height:'65%'}
    }

      var container = document.getElementById('chart4_area');
      container.style.display = null;
        var chart_discon = new google.visualization.LineChart(container);
      chart_discon.draw(data_discon, options);
}

function drawCxBaseChart(chart_data, chart_main_title)
{
    var jsonData = chart_data;
    var data_cxbase = new google.visualization.DataTable();
    data_cxbase.addColumn('string', 'Month');
    data_cxbase.addColumn('number', 'Actual Customer base');
    data_cxbase.addColumn('number', 'Forecasted Customer base');


    //alert('drawProChurnChart function loaded');

    $.each(jsonData, function(i, jsonData){
        var month = jsonData.month;
        var cxBase = parseFloat($.trim(jsonData.cxBase));
        var cxBaseTar = parseFloat($.trim(jsonData.cxBaseTar));
        data_cxbase.addRows([[month,cxBase,cxBaseTar]]);
    });


    var options = {
      //title:"Revenue"+ chart_main_title,
        hAxis: {
            title: "month"
        },
        vAxis: {
            title: 'Customer Base'
        },
        chartArea:{width:'60%',height:'65%'}
    }

      var container = document.getElementById('chart3_area');
      container.style.display = null;
        var chart_cxbase = new google.visualization.LineChart(container);
      chart_cxbase.draw(data_cxbase, options);
}

