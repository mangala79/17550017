google.charts.load('current', {packages:['corechart']});
google.charts.setOnLoadCallback();
 

function drawRevDistributionChart(chart_data, chart_main_title)
{
    var jsonData = chart_data;
    var data_revenue = new google.visualization.DataTable();
    data_revenue.addColumn('string', 'Product');
    data_revenue.addColumn('number', 'cumProRevenue');


    //alert('drawRevDistributionChart function loaded');

    $.each(jsonData, function(i, jsonData){
        var product = jsonData.proName;
        var cumProRevenue = parseFloat($.trim(jsonData.cumProRevenue));
        data_revenue.addRows([[product,cumProRevenue]]);
    });

    

    //alert('test point 5');

    var options = {
      //title:"Revenue"+ chart_main_title,
        hAxis: {
            title: "product"
        },
        vAxis: {
            title: 'Toatl Revenue'
        },
        chartArea:{width:'80%',height:'85%'}
    }

      var container = document.getElementById('chart1_area');
      container.style.display = null;
        var chart_revenue = new google.visualization.PieChart(container);
      chart_revenue.draw(data_revenue, options);
}


function drawSalesDistributionChart(chart_data, chart_main_title)
{
    var jsonData = chart_data;
    var data_sales = new google.visualization.DataTable();
    data_sales.addColumn('string', 'Product');
    data_sales.addColumn('number', 'Total Sales');


    //alert('drawSalesDistributionChart function loaded');

    $.each(jsonData, function(i, jsonData){
        var product = jsonData.proName;
        var CumMSales = parseFloat($.trim(jsonData.CumMSales));
        data_sales.addRows([[product,CumMSales]]);
    });

    

    var options = {
      //title:"Revenue"+ chart_main_title,
        hAxis: {
            title: "product"
        },
        vAxis: {
            title: 'Toatl Sales'
        },
        chartArea:{width:'80%',height:'85%'}
    }

      var container = document.getElementById('chart2_area');
      container.style.display = null;
        var chart_sales = new google.visualization.PieChart(container);
      chart_sales.draw(data_sales, options);
}


function drawChurnImpactChart(chart_data, chart_main_title)
{
    var jsonData = chart_data;
    var data_discon  = new google.visualization.DataTable();
    data_discon.addColumn('string', 'Product');
    data_discon.addColumn('number', 'Total Disconnections');


    //alert('drawRevDistributionChart function loaded');

    $.each(jsonData, function(i, jsonData){
        var product = jsonData.proName;
        var CumDis = parseFloat($.trim(jsonData.CumDis));
        data_discon.addRows([[product,CumDis]]);
    });

   

    var options = {
      //title:"Revenue"+ chart_main_title,
        hAxis: {
            title: "product"
        },
        vAxis: {
            title: 'Total Disconnections'
        },
        chartArea:{width:'80%',height:'85%'}
    }

      var container = document.getElementById('chart3_area');
      container.style.display = null;
        var chart_discon = new google.visualization.PieChart(container);
      chart_discon.draw(data_discon, options);
}


function drawRevTargetAchievementChart(chart_data, chart_main_title)
{
    var jsonData = chart_data;
    var data_rev  = new google.visualization.DataTable();
    data_rev.addColumn('string', 'Product');
    data_rev.addColumn('number', 'Total Revenue');
    data_rev.addColumn('number', 'Target');
    


    //alert('drawRevDistributionChart function loaded');

    $.each(jsonData, function(i, jsonData){
        var product = jsonData.proName;
        var cumProRevenue = parseFloat($.trim(jsonData.cumProRevenue));
        var CumRevTar = parseFloat($.trim(jsonData.CumRevTar));
        data_rev.addRows([[product,cumProRevenue,CumRevTar]]);
    });

   

    var options = {
      //title:"Revenue"+ chart_main_title,
        hAxis: {
            title: "Revenue Target Achievement"
        },
        vAxis: {
            title: 'Product'
        },
        chartArea:{width:'70%',height:'85%'}
    }

      var container = document.getElementById('chart4_area');
      container.style.display = null;
        var chart_revachievement = new google.visualization.BarChart(container);
      chart_revachievement.draw(data_rev, options);
}