function generatepdf(){

        var doc = new jsPDF();
        var YTDSales = $('#YTDSales').html();
        var YTDRevenue = $('#YTDRevenue').html();
        var YTDCxbase = $('#YTDCxbase').html();
        var YTDDis = $('#YTDDis').html();
        var YTDSaleslabel = $('#YTDSaleslabel').html();
        var YTDRevenuelabel = $('#YTDRevenuelabel').html();
        var YTDCxbaselabel = $('#YTDCxbaselabel').html();
        var YTDDislabel = $('#YTDDislabel').html();
        var DSS_Message = $('#DSS_Message').html();
        /*var specialElementHandlers = {
            '#alert_header': function (element, renderer) {
                return true;
            }
        }; */
        var chartarea1 = $('#chart1_area').html();
        var charttest = $('#chart1_area');
        var chartarea2 = $('#chart2_area').html();
        var chartarea3 = $('#chart3_area').html();
        var chartarea4 = $('#chart3_area').html();

        var M1 =  $("#M1").html();
        var M2 =  $("#M2").html();
        var M3 =  $("#M3").html();
        var M4 =  $("#M4").html();
        var M5 =  $("#M5").html();
        var M6 =  $("#M6").html();
        var M7 =  $("#M7").html();
        var M8 =  $("#M8").html();
        var M9 =  $("#M9").html();
        var M10 =  $("#M10").html();
        var M11 =  $("#M11").html();
        var m12 =  $("M12").html();
        var m13 =  $("M13").html();
        var m14 =  $("M14").html();
        var m15 =  $("M15").html();
        var m16 =  $("M16").html();
        var m17 =  $("M17").html();
        var m18 =  $("M18").html();
        var m19 =  $("M19").html();
        var m20 =  $("M20").html();
        var m21 =  $("M21").html();
        var m22 =  $("M22").html();
        var m23 =  $("M23").html();
        var m24 =  $("M24").html();
        var m25 =  $("M25").html();
        var m26 =  $("M26").html();

        var Kpilabel1 = $("#KPILabel-1").html();
        var Kpilabel2 = $("#KPILabel-2").html();
        var Kpilabel3 = $("#KPILabel-3").html();
        var Kpilabel4 = $("#KPILabel-4").html();
        var Kpilabel5 = $("#KPILabel-5").html();
        var Kpilabel6 = $("#KPILabel-6").html();
        var Kpilabel7 = $("#KPILabel-7").html();
        var Kpilabel8 = $("#KPILabel-8").html();
        var Kpilabel9 = $("#KPILabel-9").html();
        var Kpilabel10 = $("#KPILabel-10").html();
        var Kpilabel11 = $("#KPILabel-11").html();
        var Kpilabel12 = $("#KPILabel-12").html();
        var Kpilabel13 = $("#KPILabel-13").html();
        var Kpivalue1 = $("#KPIValue-1").html();
        var Kpivalue2 = $("#KPIValue-2").html();
        var Kpivalue3 = $("#KPIValue-3").html();
        var Kpivalue4 = $("#KPIValue-4").html();
        var Kpivalue5 = $("#KPIValue-5").html();
        var Kpivalue6 = $("#KPIValue-6").html();
        var Kpivalue7 = $("#KPIValue-7").html();
        var Kpivalue8 = $("#KPIValue-8").html();
        var Kpivalue9 = $("#KPIValue-9").html();
        var Kpivalue10 = $("#KPIValue-10").html();
        var Kpivalue11 = $("#KPIValue-11").html();
        var Kpivalue12 = $("#KPIValue-12").html();
        var Kpivalue13 = $("#KPIValue-13").html();


        var specialElementHandlers = {
            '#instructions': function (element, renderer) {
                return true;
            }
        };

        doc.setFont("Arial");
        doc.setFontSize(24);
        doc.setFontType("bold");
        doc.setTextColor(0,0,204);
        doc.text(85, 20, 'ProLife');
        doc.setFont("Arial");
        doc.setFontSize(10);
        doc.setFontType("bold");
        doc.setTextColor(0,0,0);
        doc.text(70, 30, 'Product Lifecycle Management System');
        doc.setFontType("normal");
        doc.setFontSize(6);
        doc.text(20, 35, 'Prolife software (Pvt) Ltd, Reid Avenue, Colombo 07');
        doc.text(20, 40, 'Web – WWW.prolife.lk   email – info@prolife.lk  Tel - 0117712345');


        doc.setLineWidth(0.5);
        doc.line(80, 45, 120, 45);
        doc.setFontSize(10);
        doc.setFontType("bold");
        doc.text(80, 50, 'Product Analysis Report');
        doc.line(80, 55, 120, 55);

        // ***************generate product name and report date ****************

        var today = new Date();
        var dd = String(today.getDate()).padStart(2, '0');
        var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
        var yyyy = today.getFullYear();
        var product = $('#product :selected').text();
        
        if (product=="select product ID"){
            product ="Overall Performance"
        }

        today = mm + '/' + dd + '/' + yyyy;
        doc.setFontType("normal");
        doc.text( 20, 65, 'Report on' );
        doc.text( 20, 70, 'Report generated on' );
        doc.text( 50, 65, product );
        doc.text( 50, 70, today );

        // **********************************************************************
        
        doc.setFont("courier");
        doc.setFontType("normal");
        doc.setTextColor(0,0,0);
        doc.text(20, 80, 'Product Key Performance Indicators');
        doc.setFontSize(10);

        doc.text(30, 90, 'Revenue Related KPI'); 
        doc.text(30, 98, 'KPI');
        doc.text(100, 98, 'Value');
        doc.text(170, 98, 'Unit');
        doc.fromHTML(YTDRevenuelabel, 30, 100, {'width': 170});
        doc.fromHTML(YTDRevenue, 100, 100, {'width': 170});
        doc.text(170, 105, 'Rs.(Mn)');
        doc.fromHTML(Kpilabel1, 30, 105, {'width': 170});
        doc.fromHTML(Kpivalue1, 100, 105, {'width': 170});
        doc.text(170, 110, '%');
        doc.fromHTML(Kpilabel5, 30, 110, {'width': 170});
        doc.fromHTML(Kpivalue5, 100, 110, {'width': 170});
        doc.text(170, 115, '%');
        doc.fromHTML(Kpilabel9, 30, 115, {'width': 170});
        doc.fromHTML(Kpivalue9, 100, 115, {'width': 170});
        doc.text(170, 120, 'Rs.(Mn)');
        doc.fromHTML(Kpilabel13, 30, 120, {'width': 170});
        doc.fromHTML(Kpivalue13, 100, 120, {'width': 170});
        doc.text(170, 125, 'Rs.');


        doc.text(30, 140, 'Sales Related KPI');
        doc.text(30, 148, 'KPI');
        doc.text(100, 148, 'Value');
        doc.text(170, 148, 'Unit');
        doc.fromHTML(YTDSaleslabel, 30, 150, {'width': 170});
        doc.fromHTML(YTDSales, 100, 150, {'width': 170});
        doc.text(170, 155, 'Nos');
        doc.fromHTML(Kpilabel2, 30, 155, {'width': 170});
        doc.fromHTML(Kpivalue2, 100, 155, {'width': 170});
        doc.text(170, 160, '%');
        doc.fromHTML(Kpilabel6, 30, 160, {'width': 170});
        doc.fromHTML(Kpivalue6, 100, 160, {'width': 170});
        doc.text(170, 165, '%');
        doc.fromHTML(Kpilabel10, 30, 165, {'width': 170});
        doc.fromHTML(Kpivalue10, 100, 165, {'width': 170});
        doc.text(170, 170, 'Nos');
        

        doc.text(30, 190, 'Churn Mitigation Related KPI'); 
        doc.text(30, 198, 'KPI');
        doc.text(100, 198, 'Value');
        doc.text(170, 198, 'Unit');
        doc.fromHTML(YTDDislabel, 30, 200, {'width': 170});
        doc.fromHTML(YTDDis, 100, 200, {'width': 170});
        doc.text(170, 205, 'Nos');
        doc.fromHTML(Kpilabel4, 30, 205, {'width': 170});
        doc.fromHTML(Kpivalue4, 100, 205, {'width': 170});
        doc.text(170, 210, '%');
        doc.fromHTML(Kpilabel8, 30, 210, {'width': 170});
        doc.fromHTML(Kpivalue8, 100, 210, {'width': 170});
        doc.text(170, 215, '%');
        doc.fromHTML(Kpilabel11, 30, 215, {'width': 170});
        doc.fromHTML(Kpivalue11, 100, 215, {'width': 170});
        doc.text(170, 220, 'Nos');

        
        // ************************************Footer - Page 1***********************************
        doc.setTextColor(160,160,160);
        addWrappedText({
          text: "Warning - This report contains business critical information and internal use only. Please take and extra percussions on disseminating the report in any mean. All ISM policies applicable for internal confidential document are applicable for this document.", // long string here
          textWidth: 240,
          doc,

          // Optional
          fontSize: '8',
          fontType: 'normal',
          lineSpacing: 4,               // Space between lines
          xPosition: 20,                // Text offset from left of document
          initialYPosition: 260,         // Initial offset from top of document; set based on prior objects in document
          pageWrapInitialYPosition: 10  // Initial offset from top of document when page-wrapping
        }); 
        

        doc.setLineWidth(0.5);
        doc.setDrawColor(0, 0, 204);
        doc.line(20, 270, 200, 270);
        doc.setFontSize(8);
        doc.setFontType("italic");
        doc.setTextColor(160,160,160);
        doc.text(20, 275, 'System generated report of the “ProLife” Product Lifecycle Management System ');

        //********************************New Page **************************************
        doc.addPage();

        doc.text(30, 20, 'Customer Base Related KPI'); 
        doc.text(30, 28, 'KPI');
        doc.text(100, 28, 'Value');
        doc.text(170, 28, 'Unit');
        doc.fromHTML(YTDCxbaselabel, 30, 30, {'width': 170});
        doc.fromHTML(YTDCxbase, 100, 30, {'width': 170});
        doc.text(170, 35, 'Nos');
        doc.fromHTML(Kpilabel3, 30, 35, {'width': 170});
        doc.fromHTML(Kpivalue3, 100, 35, {'width': 170});
        doc.text(170, 40, '%');
        doc.fromHTML(Kpilabel7, 30, 40, {'width': 170});
        doc.fromHTML(Kpivalue7, 100, 40, {'width': 170});
        doc.text(170, 45, '%');
        doc.fromHTML(Kpilabel12, 30, 45, {'width': 170});
        doc.fromHTML(Kpivalue12, 100, 45, {'width': 170});
        doc.text(170, 50, 'Nos');


        doc.setFontSize(12);
        doc.setFontType("bold");
        doc.text(20, 70, 'Special Observations and Comments'); 

        doc.fromHTML(M1, 20, 80, {'width': 170 });
        doc.fromHTML(M13, 20, 85, {'width': 170 });
        doc.fromHTML(M14, 20, 90, {'width': 170 });
        doc.fromHTML(M15, 20, 95, {'width': 170 });
        doc.fromHTML(M20, 20, 100, {'width': 170 });
        doc.fromHTML(M21, 20, 105, {'width': 170 });
        doc.fromHTML(M22, 20, 110, {'width': 170 });
        doc.fromHTML(M12, 20, 115, {'width': 170 });
        doc.fromHTML(M2, 20, 120, {'width': 170 });
        doc.fromHTML(M3, 20, 125, {'width': 170 });
        doc.fromHTML(M5, 20, 130, {'width': 170 });
        doc.fromHTML(M6, 20, 135, {'width': 170 });
        doc.fromHTML(M7, 20, 140, {'width': 170 });
        doc.fromHTML(M8, 20, 145, {'width': 170 });
        doc.fromHTML(M9, 20, 150, {'width': 170 });
        doc.fromHTML(M10, 20, 155, {'width': 170 });
        

        doc.text(20, 166, 'Attention need areas'); 

        doc.fromHTML(M16, 20, 175, {'width': 170 });
        doc.fromHTML(M17, 20, 180, {'width': 170 });
        doc.fromHTML(M18, 20, 185, {'width': 170 });
        doc.fromHTML(M19, 20, 190, {'width': 170 });
        doc.fromHTML(M23, 20, 195, {'width': 170 });
        doc.fromHTML(M24, 20, 200, {'width': 170 });
        doc.fromHTML(M21, 20, 205, {'width': 170 });




    


        // ************************************Footer - Page 2***********************************
        doc.setTextColor(160,160,160);
        addWrappedText({
          text: "Warning - This report contains business critical information and internal use only. Please take and extra percussions on disseminating the report in any mean. All ISM policies applicable for internal confidential document are applicable for this document.", // long string here
          textWidth: 240,
          doc,

          // Optional
          fontSize: '8',
          fontType: 'normal',
          lineSpacing: 4,               // Space between lines
          xPosition: 20,                // Text offset from left of document
          initialYPosition: 260,         // Initial offset from top of document; set based on prior objects in document
          pageWrapInitialYPosition: 10  // Initial offset from top of document when page-wrapping
        }); 


        doc.setLineWidth(0.5);
        doc.setDrawColor(0, 0, 204);
        doc.line(20, 270, 200, 270);
        doc.setFontSize(8);
        doc.setFontType("italic");
        doc.setTextColor(160,160,160);
        doc.text(20, 275, 'System generated report of the “ProLife” Product Lifecycle Management System ');

        //********************************New Page **************************************
        doc.addPage();

        doc.setFontType("normal");
        doc.setFontSize(8);
        doc.text(190, 20, 'Annex I ');

        doc.setFontType("bold");
        doc.setTextColor(0,0,0);
        doc.setFontSize(12);
        doc.text(20, 30, 'Abbreviations ');

        doc.setFontType("normal");
        doc.setFontSize(8);

        doc.text(20, 40, 'AACBGPM');
        doc.text(50, 40, 'Aggregated Average Customer Base Growth per Month');
        doc.text(20, 45, 'AADPM');
        doc.text(50, 45, 'Aggregated Average Disconnections per Month');
        doc.text(20, 50, 'AARPM');
        doc.text(50, 50, 'Aggregated Average Revenue per Month  ');
        doc.text(20, 55, 'AASPM');
        doc.text(50, 55, 'Aggregated Average Sales per Month  ');
        doc.text(20, 60, 'ACBAPM');
        doc.text(50, 60, 'Average Customer Base Growth per Month  ');
        doc.text(20, 65, 'ADPM');
        doc.text(50, 65, 'Average Disconnections per Month  ');
        doc.text(20, 70, 'ARAR');
        doc.text(50, 70, 'Average Revenue Achievement Rate  ');
        doc.text(20, 75, 'ARPM');
        doc.text(50, 75, 'Average Revenue per Month  ');
        doc.text(20, 80, 'ARPU');
        doc.text(50, 80, 'Average Revenue per User ');
        doc.text(20, 85, 'ASAR');
        doc.text(50, 85, 'Aggregated Sales Achievement Rate  ');
        doc.text(20, 90, 'ASPM');
        doc.text(50, 90, 'Average Sales per Month  ');
        doc.text(20, 95, 'CAR');
        doc.text(50, 95, 'Customer base Achievement Rate');
        doc.text(20, 100, 'CMAR');
        doc.text(50, 100, 'Churn Mitigation Achievement Rate');
        doc.text(20, 105, 'RAR');
        doc.text(50, 105, 'Revenue Achievement Rate');
        doc.text(20, 110, 'SAR');
        doc.text(50, 110, 'Sales Achievement Rate');
        doc.text(20, 115, 'Y2DAD');
        doc.text(50, 115, 'Year to Date Aggregated Disconnection ');
        doc.text(20, 120, 'Y2DAR');
        doc.text(50, 120, 'Year to Date Aggregated Revenue');
        doc.text(20, 125, 'Y2DAS');
        doc.text(50, 125, 'Year to Date Aggregated Sales');
        doc.text(20, 130, 'Y2DC');
        doc.text(50, 130, 'Year to Date Customer Base');
        doc.text(20, 135, 'Y2DD');
        doc.text(50, 135, 'Year to Date Disconnection');
        doc.text(20, 140, 'Y2DR');
        doc.text(50, 140, 'Year to Date Revenue');
        doc.text(20, 145, 'Y2DS');
        doc.text(50, 145, 'Year to Date Sales');
        doc.text(20, 150, 'YOYAD');
        doc.text(50, 150, 'Year on Year Aggregated Disconnection ');
        doc.text(20, 155, 'YOYAR');
        doc.text(50, 155, 'Year on Year Aggregated Revenue');
        doc.text(20, 160, 'YOYAS');
        doc.text(50, 160, 'Year on Year Aggregated Sales');
        doc.text(20, 165, 'YOYC');
        doc.text(50, 165, 'Year on Year Customer base growth');
        doc.text(20, 170, 'YOYD');
        doc.text(50, 170, 'Year on Year Disconnection ');
        doc.text(20, 175, 'YOYR');
        doc.text(50, 175, 'Year on Year Revenue growth');
        doc.text(20, 180, 'YOYS');
        doc.text(50, 180, 'Year on Year Sales growth');

        // ************************************Footer - Page 3***********************************
        doc.setTextColor(160,160,160);
        addWrappedText({
          text: "Warning - This report contains business critical information and internal use only. Please take and extra percussions on disseminating the report in any mean. All ISM policies applicable for internal confidential document are applicable for this document.", // long string here
          textWidth: 240,
          doc,

          // Optional
          fontSize: '8',
          fontType: 'normal',
          lineSpacing: 4,               // Space between lines
          xPosition: 20,                // Text offset from left of document
          initialYPosition: 260,         // Initial offset from top of document; set based on prior objects in document
          pageWrapInitialYPosition: 10  // Initial offset from top of document when page-wrapping
        }); 


        doc.setLineWidth(0.5);
        doc.setDrawColor(0, 0, 204);
        doc.line(20, 270, 200, 270);
        doc.setFontSize(8);
        doc.setFontType("italic");
        doc.setTextColor(160,160,160);
        doc.text(20, 275, 'System generated report of the “ProLife” Product Lifecycle Management System ');

        //********************************New Page **************************************
        doc.addPage();
        doc.setFontType("normal");
        doc.setFontSize(8);
        doc.text(190, 20, 'Annex II ');

        doc.setFontType("bold");
        doc.setTextColor(0,0,0);
        doc.setFontSize(12);
        doc.text(20, 30, 'Calculations  ');


        doc.setFontType("normal");
        doc.setFontSize(10);
        doc.text(30, 50, 'Year on Year Calculations');
        doc.text(30, 60, 'YOY(S/R/D/C)  =  ');
        doc.setLineWidth(0.25);
        doc.line(60, 60, 140, 60);
        doc.text(60, 58, '[This year Y2D(S/R/D/C) – Last year Y2D(S/R/D/C) ]');
        doc.text(80, 64, 'Last year Y2D(S/R/D/C)');


        doc.text(30, 80, 'Achievement Rates ');
        doc.text(30, 90, '(R/S/CM/C)AR  =  ');
        doc.setLineWidth(0.25);
        doc.line(60, 90, 110, 90);
        doc.text(60, 88, 'This year Y2D(S/R/D/C) actual ');
        doc.text(60, 94, 'Last year Y2D(S/R/D/C) target');

        doc.text(30, 110, 'Month Averages ');
        doc.text(30, 120, 'A(R/S/D/CBG)PM  =  ');
        doc.setLineWidth(0.25);
        doc.line(60, 120, 150, 120);
        doc.text(60, 118, 'T(Revenue/Sales/Disconnections/Cx base growth) for last 12 Month');
        doc.text(105, 124, '12');


        // ************************************Footer - Page 4***********************************
        doc.setTextColor(160,160,160);
        addWrappedText({
          text: "Warning - This report contains business critical information and internal use only. Please take and extra percussions on disseminating the report in any mean. All ISM policies applicable for internal confidential document are applicable for this document.", // long string here
          textWidth: 240,
          doc,

          // Optional
          fontSize: '8',
          fontType: 'normal',
          lineSpacing: 4,               // Space between lines
          xPosition: 20,                // Text offset from left of document
          initialYPosition: 260,         // Initial offset from top of document; set based on prior objects in document
          pageWrapInitialYPosition: 10  // Initial offset from top of document when page-wrapping
        }); 


        doc.setLineWidth(0.5);
        doc.setDrawColor(0, 0, 204);
        doc.line(20, 270, 200, 270);
        doc.setFontSize(8);
        doc.setFontType("italic");
        doc.setTextColor(160,160,160);
        doc.text(20, 275, 'System generated report of the “ProLife” Product Lifecycle Management System ');

        

        /* test code 1
        ***************
        html2canvas(charttest , {
            onrendered: function(canvas) {
                Canvas2Image.saveAsPNG(canvas)
                }
            });
        
        
        //test code 2
        //*************
        html2canvas($("#chart1_area"), {
            onrendered: function(canvas) {
                var imageData = canvas.toDataURL("image/jpeg");
                //var image = new Image();
                //image = Canvas2Image.convertToJPEG(canvas);
                //var doc = new jsPDF();
                doc.addImage(imageData, 'JPEG', 20, 140);
                //theCanvas = canvas;
                //document.body.appendChild(canvas);

                // Convert and download as image 
                //Canvas2Image.saveAsPNG(canvas); 
                //$("#img-out").append(canvas);
                // Clean up 
                //document.body.removeChild(canvas);
            }
        });

        */
        console.log(doc);
        
        
        //To wrap the long text
        function addWrappedText({text, textWidth, doc, fontSize = 10, fontType = 'normal', lineSpacing = 7, xPosition = 10, initialYPosition = 10, pageWrapInitialYPosition = 10}) {
          var textLines = doc.splitTextToSize(text, textWidth); // Split the text into lines
          var pageHeight = doc.internal.pageSize.height;        // Get page height, well use this for auto-paging
          doc.setFontType(fontType);
          doc.setFontSize(fontSize);

          var cursorY = initialYPosition;

          textLines.forEach(lineText => {
            if (cursorY > pageHeight) { // Auto-paging
              doc.addPage();
              cursorY = pageWrapInitialYPosition;
            }
            doc.text(xPosition, cursorY, lineText);
            cursorY += lineSpacing;
          })
        }

       
        // Save the PDF
        doc.save('Analysis Report.pdf');
            }