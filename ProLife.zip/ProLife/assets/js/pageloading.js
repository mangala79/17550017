$( window ).on( "load", function() {
    console.log( "window loaded" );
    var year = new Date().getFullYear();
        
    document.getElementById("chart1_heading").innerHTML = "Product Revenue contribution - " + year ;
    document.getElementById("chart2_heading").innerHTML = "Sale contribution for each product - " + year ;
    document.getElementById("chart3_heading").innerHTML = "Product wise customer churn impact - " + year ;
    document.getElementById("chart4_heading").innerHTML = "Revenue target achievement of each product - " + year ;
    load_summary_data(year);
    load_aggregated_KPI(year);
    });    