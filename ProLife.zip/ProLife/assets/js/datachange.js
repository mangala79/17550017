$(document).ready(function(){
    $('.form-control').change(function(){
       var year = $("#year").val();
       var product = $("#product").val();
       var manager = $("#manager").val();
       //var productname = $("#product:selected").text();



        if(($("#year").val()=='' && $("#product").val())!= '')
            {
                var d = new Date();
                var year = d.getFullYear();
                document.getElementById("chart1_heading").innerHTML = "Product Revenue  "+ year; 
                document.getElementById("chart2_heading").innerHTML = "Sale performance "+ year;
                document.getElementById("chart3_heading").innerHTML = "Customer base "+ year;
                document.getElementById("chart4_heading").innerHTML = "Churn rate "+ year;
                load_instructions(year,product);
                load_productwise_data(year,product, 'Month Wise Data For');
                
                //alert(product);
                //alert(year);
                        
            }
        
        if(($("#year").val() && $("#product").val())!= '')
            {
                document.getElementById("chart1_heading").innerHTML = "Product Revenue  "+ year; 
                document.getElementById("chart2_heading").innerHTML = "Sale performance "+ year;
                document.getElementById("chart3_heading").innerHTML = "Customer base "+ year;
                document.getElementById("chart4_heading").innerHTML = "Churn rate "+ year;
                load_instructions(year,product);
                load_productwise_data(year,product, 'Month Wise Data For');
                
                //alert(product);
                //alert(year);
                        
            }


        if($("#year").val()!=='' && $("#product").val() =='')
            {
                document.getElementById("chart1_heading").innerHTML = "Product Revenue contribution" + year ;
                document.getElementById("chart2_heading").innerHTML = "Sale contribution for each product - " + year ;
                document.getElementById("chart3_heading").innerHTML = "Product wise customer churn impact - " + year ;
                document.getElementById("chart4_heading").innerHTML = "Revenue target achievement of each product - " + year ;
                load_summary_data(year);
                load_aggregated_KPI(year);
                        
            }

        if(($("#manager").val())!= '')
            {
                
                load_managerwise_data(manager);
                
                //alert(product);
                //alert(year);
                        
            }

        


       
    });

});