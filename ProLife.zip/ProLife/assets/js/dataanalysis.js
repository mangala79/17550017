var m1 =  document.getElementById("M1");
var m2 =  document.getElementById("M2");
var m3 =  document.getElementById("M3");
var m4 =  document.getElementById("M4");
var m5 =  document.getElementById("M5");
var m6 =  document.getElementById("M6");
var m7 =  document.getElementById("M7");
var m8 =  document.getElementById("M8");
var m9 =  document.getElementById("M9");
var m10 =  document.getElementById("M10");
var m11 =  document.getElementById("M11");
var m12 =  document.getElementById("M12");
var m13 =  document.getElementById("M13");
var m14 =  document.getElementById("M14");
var m15 =  document.getElementById("M15");
var m16 =  document.getElementById("M16");
var m17 =  document.getElementById("M17");
var m18 =  document.getElementById("M18");
var m19 =  document.getElementById("M19");
var m20 =  document.getElementById("M20");
var m21 =  document.getElementById("M21");
var m22 =  document.getElementById("M22");
var m23 =  document.getElementById("M23");
var m24 =  document.getElementById("M24");
var m25 =  document.getElementById("M25");
var m26 =  document.getElementById("M26");
var ytdsaleslabel =  document.getElementById("YTDSaleslabel");
var ytdrevlabel =  document.getElementById("YTDRevenuelabel");
var ytdcxbaselabel =  document.getElementById("YTDCxbaselabel");
var ytddislabel =  document.getElementById("YTDDislabel");
var ytdsales =  document.getElementById("YTDSales");
var ytdrev =  document.getElementById("YTDRevenue");
var ytdcxbase =  document.getElementById("YTDCxbase");
var ytddis =  document.getElementById("YTDDis");

var kpilabel1 = document.getElementById("KPILabel-1");
var kpilabel2 = document.getElementById("KPILabel-2");
var kpilabel3 = document.getElementById("KPILabel-3");
var kpilabel4 = document.getElementById("KPILabel-4");
var kpilabel5 = document.getElementById("KPILabel-5");
var kpilabel6 = document.getElementById("KPILabel-6");
var kpilabel7 = document.getElementById("KPILabel-7");
var kpilabel8 = document.getElementById("KPILabel-8");
var kpilabel9 = document.getElementById("KPILabel-9");
var kpilabel10 = document.getElementById("KPILabel-10");
var kpilabel11 = document.getElementById("KPILabel-11");
var kpilabel12 = document.getElementById("KPILabel-12");
var kpilabel13 = document.getElementById("KPILabel-13");
var kpivalue1 = document.getElementById("KPIValue-1");
var kpivalue2 = document.getElementById("KPIValue-2");
var kpivalue3 = document.getElementById("KPIValue-3");
var kpivalue4 = document.getElementById("KPIValue-4");
var kpivalue5 = document.getElementById("KPIValue-5");
var kpivalue6 = document.getElementById("KPIValue-6");
var kpivalue7 = document.getElementById("KPIValue-7");
var kpivalue8 = document.getElementById("KPIValue-8");
var kpivalue9 = document.getElementById("KPIValue-9");
var kpivalue10 = document.getElementById("KPIValue-10");
var kpivalue11 = document.getElementById("KPIValue-11");
var kpivalue12 = document.getElementById("KPIValue-12");
var kpivalue13 = document.getElementById("KPIValue-13");


function load_instructions(year,product)
  {

      $.ajax("DashboardCon/fetchProductSummaryData",{
          method:"POST",
          data:{year:year,product:product},
          dataType:"JSON",      
          success:function(data)
            {
                console.log("success");
                //alert(data[0][0].cumProRevenue);        
                productanalysis(data);                     
            },
          error: function(xhr,ajaxOptions, thrownError) 
            {
            alert('load_instructions function failed. Check the data availability' );
            //alert(xhr.status);
            //alert(thrownError);
            console.log("error");
            }
          })
      
  }



function load_aggregated_KPI(year)
  {
      //this function load the KPIs of the dashboard at the time where product is not selected
      //It indicate the aggregated KPI of all products 

      $.ajax("DashboardCon/fetchKPISummaryData",{
          method:"POST",
          data:{year:year},
          dataType:"JSON",      
          success:function(data)
            {
                console.log("success");
                //alert(data[0][0].AggregatedCumRev);        
                overallanalysis(data);                     
            },
          error: function(xhr,ajaxOptions, thrownError) 
            {
            alert('load_aggregated_KPI. Check the data availability' );
            //alert(xhr.status);
            //alert(thrownError);
            console.log("error");
            }
          })
      
  }



function overallanalysis(stat)
  {
    
    
    var jsonData = stat;
    var AggregatedCumRev = jsonData[0][0].AggregatedCumRev;
    var AggregatedCumSales = jsonData[0][0].AggregatedCumSales;
    var AggregatedCumDis = jsonData[0][0].AggregatedCumDis;
    var AggregatedCumRevenueTar = jsonData[0][0].AggregatedCumRevenueTar;
    var AggregatedCumSalesTar = jsonData[0][0].AggregatedCumSalesTar;
    var AggregatedCumDisTar = jsonData[0][0].AggregatedCumDisTar;
    var AggregatedCumProRevenue_yearbefore = jsonData[1][0].AggregatedCumProRevenue_yearbefore;
    var AggregatedCumSales_yearbefore = jsonData[1][0].AggregatedCumSales_yearbefore;
    var AggregatedCumDis_yearbefore = jsonData[1][0].AggregatedCumDis_yearbefore;
    var AggregatedCumProRevenue_lastyeartailing = jsonData[2][0].AggregatedCumProRevenue_lastyeartailing;
    var AggregatedCumSales_lastyeartailing = jsonData[2][0].AggregatedCumSales_lastyeartailing;
    var AggregatedCumDis_lastyeartailing = jsonData[2][0].AggregatedCumDis_lastyeartailing;
    var YOYAR = (((AggregatedCumRev-AggregatedCumProRevenue_yearbefore)/AggregatedCumProRevenue_yearbefore)*100).toFixed(2);
    var YOYAS = (((AggregatedCumSales-AggregatedCumSales_yearbefore)/AggregatedCumSales_yearbefore)*100).toFixed(2);
    var YOYAD = (((AggregatedCumDis-AggregatedCumDis_yearbefore)/AggregatedCumDis_yearbefore)*100).toFixed(2);
    var ARAR = ((AggregatedCumRev/AggregatedCumRevenueTar)*100).toFixed(2);
    var ASAR = ((AggregatedCumSales/AggregatedCumSalesTar)*100).toFixed(2);
    var ACMAR = ((AggregatedCumDis/AggregatedCumDisTar)*100).toFixed(2);
    var AARPM = ((AggregatedCumRev+AggregatedCumProRevenue_lastyeartailing)/12).toFixed(2);
    var AASPM = ((AggregatedCumSales+AggregatedCumSales_lastyeartailing)/12).toFixed(2);
    var AADPM = ((AggregatedCumDis+AggregatedCumDis_lastyeartailing)/12).toFixed(2);

    ytdsaleslabel.innerHTML = 'Aggregated Sales Volume';
    ytdrevlabel.innerHTML = 'Aggregated Revenue';
    ytdcxbaselabel.innerHTML = 'Cx Base';
    ytddislabel.innerHTML = 'Aggregated Disconnections';
    ytdsales.innerHTML = AggregatedCumSales;
    ytdrev.innerHTML = AggregatedCumRev;
    ytdcxbase.innerHTML = 'N/A';
    ytddis.innerHTML = AggregatedCumDis;

    kpilabel1.innerHTML = 'YOYAR  ';
    kpilabel2.innerHTML = 'YOYAS  ';
    kpilabel4.innerHTML = 'YOYAD  ';
    kpilabel5.innerHTML = 'ARAR  ';
    kpilabel6.innerHTML = 'ASAR  ';
    kpilabel8.innerHTML = 'ACMAR  ';
    kpilabel9.innerHTML = 'AARPM  ';
    kpilabel10.innerHTML = 'AASPM  ';
    kpilabel11.innerHTML = 'AADPM  ';
    kpivalue1.innerHTML = YOYAR +"   ";
    kpivalue2.innerHTML = YOYAS +"   ";
    kpivalue4.innerHTML = YOYAD +"   ";
    kpivalue5.innerHTML = ARAR +"   ";
    kpivalue6.innerHTML = ASAR +"   ";
    kpivalue8.innerHTML = ACMAR +"  ";
    kpivalue9.innerHTML = AARPM +"   " ;
    kpivalue10.innerHTML = AASPM +"   " ;
    kpivalue11.innerHTML = AADPM +"   " ;
  
  }



function productanalysis(stat)
  {
    
    var jsonData = stat;
    var cumProRevenue = jsonData[0][0].cumProRevenue;
    var cumSales = jsonData[0][0].cumSales;
    var cumDis = jsonData[0][0].cumDis;
    var cxBase = jsonData[0][0].cxBase;
    var proName = jsonData[0][0].proName;
    var y2dcxbase = (cxBase+cumSales-cumDis);
    var cumProRevenue_yearbefore = jsonData[1][0].cumProRevenue_yearbefore;
    var cumSales_yearbefore = jsonData[1][0].cumSales_yearbefore;
    var cumDis_yearbefore = jsonData[1][0].cumDis_yearbefore;
    var cxBase_yearbefore = jsonData[1][0].cxBase_yearbefore;
    var cumRevenueTar = jsonData[0][0].cumRevenueTar;
    var cumSalesTar = jsonData[0][0].cumSalesTar;
    var cumDisTar = jsonData[0][0].cumDisTar;
    var cxBaseTar = jsonData[0][0].cxBaseTar;
    var cumProRevenue_3yearbefore = jsonData[2][0].cumProRevenue_3yearbefore;
    var cumSales_3yearbefore = jsonData[2][0].cumSales_3yearbefore;
    var cumDis_3yearbefore = jsonData[2][0].cumDis_3yearbefore;
    var cxBase_3yearbefore = jsonData[2][0].cxBase_3yearbefore;
    var proName = jsonData[3][0].proName;
    var launchDate = jsonData[3][0].launchDate;
    var AggregatedCumRev = jsonData[4][0].AggregatedCumRev;
    var cumProRevenue_lastyeartailing = jsonData[5][0].cumProRevenue_lastyeartailing;
    var cumSales_lastyeartailing = jsonData[5][0].cumSales_lastyeartailing;
    var cumDis_lastyeartailing = jsonData[5][0].cumDis_lastyeartailing;
    var cxBase_lastyeartailing = jsonData[5][0].cxBase_lastyeartailing;
    var R = (cumProRevenue>=cumRevenueTar)?"true":"false";
    var C = ((cxBase+cumSales-cumDis)>=(cxBaseTar+cumSalesTar-cumDisTar))?"true":"false";
    var S = (cumSales>=cumSalesTar)?"true":"false";
    var D = (cumDis>=cumDisTar)?"true":"false";
    var YOYR = (((cumProRevenue-cumProRevenue_yearbefore)/cumProRevenue_yearbefore)*100).toFixed(2);
    var YOYS = (((cumSales-cumSales_yearbefore)/cumSales_yearbefore)*100).toFixed(2);
    var YOYD = (((cumDis-cumDis_yearbefore)/cumDis_yearbefore)*100).toFixed(2);
    var YOYC = (((cxBase-cxBase_yearbefore)/cxBase_yearbefore)*100).toFixed(2);
    var YOYR3 = ((cumProRevenue-cumProRevenue_3yearbefore)/(cumProRevenue_3yearbefore*3))*100;
    var YOYS3 = ((cumSales-cumSales_3yearbefore)/(cumSales_3yearbefore*3))*100;
    var YOYD3 = ((cumDis-cumDis_3yearbefore)/(cumDis_3yearbefore*3))*100;
    var YOYC3 = ((cxBase-cxBase_3yearbefore)/(cxBase_3yearbefore*3))*100;
    var RAR = ((cumProRevenue/cumRevenueTar)*100).toFixed(2);
    var SAR = ((cumSales/cumSalesTar)*100).toFixed(2);
    var CAR = ((cxBase/cxBaseTar)*100).toFixed(2);
    var CMAR = ((cumDisTar/cumDis)*100).toFixed(2);
    var RS = (cumProRevenue/AggregatedCumRev);
    var MS = (RS>=0.2)?"high":"low";
    var ARPM = ((cumProRevenue+cumProRevenue_lastyeartailing)/12).toFixed(2);
    var ASPM = ((cumSales+cumSales_lastyeartailing)/12).toFixed(2);
    var ADPM = ((cumDis+cumDis_lastyeartailing)/12).toFixed(2);
    var ACBGPM = ((cumProRevenue+cumProRevenue_lastyeartailing)/12).toFixed(2);// Average Cx Base growth per month
    var ARPU = ((cumProRevenue+cumProRevenue_lastyeartailing)*1000000/(y2dcxbase*12)).toFixed(2);
    var SPL ='unknown';
    var d = new Date();
    var thisyear = d.getFullYear();
    var LS = thisyear-launchDate;
    var product = $("#product").val();
    load_product_campaigns(thisyear,product,stat);

    if (RAR>100){
      m16.innerHTML = "";
      m12.innerHTML = "Product has achieved the Revenue targets";
      }
    else{
      m12.innerHTML = "";
      m16.innerHTML = "Product has not achieved the Revenue targets";
      }

    if (SAR>100){
      m17.innerHTML = "";
      m13.innerHTML = "Product has achieved the Sales targets";
      }
    else{
      m13.innerHTML = "";
      m17.innerHTML = "Product has not achieved the Sales targets";
      }

    if (CAR>100){
      m18.innerHTML = "";
      m14.innerHTML = "Product has achieved the Customer base  targets";
      }
    else{
      m14.innerHTML = "";
      m18.innerHTML = "Product has not achieved the Customer base targets";
      }

    if (CMAR>100){
      m19.innerHTML = "";
      m15.innerHTML = "Product has achieved the customer churn mitigation targets";
      }
    else{
      m15.innerHTML = "";
      m19.innerHTML = "Product has not achieved the customer churn mitigation targets";
      }


    if(SAR>100 && CMAR>0){
      m23.innerHTML = "";
      m24.innerHTML = "";
      m20.innerHTML = "Market attraction of the product is good and it is very competitive in the market";
      }
    else if (SAR>100 && CMAR<=0){
      m20.innerHTML = "Market attraction of the product is good but not competitive in the market";
      m24.innerHTML = "Cheek the quality aspect of the sales ";
      }
    else if (SAR<=100 && CMAR>0){
      m24.innerHTML = "";
      m20.innerHTML = "Product have poor market attraction but very competitive in the market";
      }
    else{
      m20.innerHTML = "";
      m21.innerHTML = "";
      m22.innerHTML = "";
      m24.innerHTML = "";
      m23.innerHTML = "Product nether attractive nor competitive in the market.";
      m24.innerHTML = "Need immediate product revamp";
    }
    
    



    //console.log(jsonData);
    
    ytdsaleslabel.innerHTML = 'Y2D Sales';
    ytdrevlabel.innerHTML = 'Y2D Revenue';
    ytdcxbaselabel.innerHTML = 'Y2D Cx Base';
    ytddislabel.innerHTML = 'Y2D Disconnections';
    kpilabel1.innerHTML = 'YOYR  ';
    kpilabel2.innerHTML = 'YOYS  ';
    kpilabel3.innerHTML = 'YOYC  ';
    kpilabel4.innerHTML = 'YOYD  ';
    kpilabel5.innerHTML = 'RAR  ';
    kpilabel6.innerHTML = 'SAR  ';
    kpilabel7.innerHTML = 'CAR  ';
    kpilabel8.innerHTML = 'CMAR  ';
    kpilabel9.innerHTML = 'ARPM  ';
    kpilabel10.innerHTML = 'ASPM  ';
    kpilabel11.innerHTML = 'ADPM  ';
    kpilabel12.innerHTML = 'ACBGPM  ';
    kpilabel13.innerHTML = 'ARPU  ';
    ytdsales.innerHTML = cumSales;
    ytdrev.innerHTML = cumProRevenue;
    ytdcxbase.innerHTML = y2dcxbase;
    ytddis.innerHTML = cumDis;
    kpivalue1.innerHTML = YOYR +"    ";
    kpivalue2.innerHTML = YOYS +"    ";
    kpivalue3.innerHTML = YOYC +"    ";
    kpivalue4.innerHTML = YOYD +"    ";
    kpivalue5.innerHTML = RAR +"    ";
    kpivalue6.innerHTML = SAR +"    ";
    kpivalue7.innerHTML = CAR +"    ";
    kpivalue8.innerHTML = CMAR +"    ";
    kpivalue9.innerHTML = ARPM +"    " 
    kpivalue10.innerHTML = ASPM +"   " ;
    kpivalue11.innerHTML = ADPM +"    " ;
    kpivalue12.innerHTML = ACBGPM +"    " ;
    kpivalue13.innerHTML = ARPU +"    " ;



    


    /* ************************Logic to identify the stage of the product lifecycle - start***************************  */

    if (YOYR3>=20) {
      SPL = "Growth";
      } 
    else if (((YOYR3<20) && (YOYR3>= -20))&&LS<4){
          SPL = "PreMaturity";
          m1.innerHTML = "This product is in its’ “PreMaturity” stage of the product lifecycle";
          } 
    else if (((YOYR3<20) && (YOYR3>= -20))&&LS>4){
          SPL = "Maturity";
          m1.innerHTML = "This product is in its’ “Maturity” stage of the product lifecycle";
          } 
    else if (YOYR3<-20 && LS>7 ) {
          SPL = "Declining";
          m1.innerHTML = "This product is in its’ “Declining” stage of the product lifecycle";
          } 
    else {
      SPL = "Product faliure";
      m1.innerHTML = "This product is identified as product failure ";

      }

    /* ************************Logic to identify the stage of the product lifecycle - end***************************  */



    /* ************************start of message logics***************************  */   
      if (R=="true") 
      {
        //m1.innerHTML = "Well done!. ";
        //m2.innerHTML = "You have achieved revenue targets ";
      
      }

      else 
      {
        m2.innerHTML = "";
      }

      if (C=="true")
      {
        //m1.innerHTML = "Well done!. ";
        //m3.innerHTML = "You have achieved customer base  targets";
      }

      else 
      {
        m3.innerHTML = "";
      }

      if ((R && !C)=="true")
      {
        //m1.innerHTML = "Well done!. ";
        m4.innerHTML = "Your ARPU is improving";
      }

      else 
      {
        m4.innerHTML = "";
      }

      if ((!R && C)=="true")
      {
        //m1.innerHTML = "Warning!. ";
        m5.innerHTML = "Your ARPU is dropping";
      }

      else 
      {
        m5.innerHTML = "";
      }

      if (((!R&&C&&S)||(!R&&S&&!D))=="true")
      {
        //m1.innerHTML = "Warning!. ";
        m6.innerHTML = "Be vigilant about the quality of sales";
      }

      else 
      {
        m6.innerHTML = "";
      }

      if ((!R&&C&&S)=="true")
      {
        //m1.innerHTML = "Warning!. ";
        m7.innerHTML = "Be vigilant about the suspended customer base";
      }

      else 
      {
        m7.innerHTML = "";
      }
    
      if ((!R&&!C)=="true")
      {
        //m1.innerHTML = "Warning!. ";
        m8.innerHTML = "Revenue and customer base targets are not achieving";
      }

      else 
      {
        m8.innerHTML = "";
      }

       if (((!R&&!C)||(!R&&!S&&!D))=="true")
      {
        //m1.innerHTML = "Suggestion... ";
        m9.innerHTML = "Need immediate product revision";
      }

      else 
      {
        m9.innerHTML = "";
      }

      if ((!R&&C&&!S&&D)=="true")
      {
        //m1.innerHTML = "Suggestion... ";
        m10.innerHTML = "Need to intensify the marketing activities";
      }

      else 
      {
        m10.innerHTML = "";
      } 

      if (((!R&&C&&!S)||(!R&&!S&&D))=="true")
      {
        //m1.innerHTML = "Suggestion... ";
        m11.innerHTML = "Need to improve the sales";
      } 

      else 
      {
        m11.innerHTML = "";
      } 

    /* ************************End of message logics***************************  */  

        //alert(<Enter the parameter need to check>);
        
       
  }


function load_product_campaigns(year,product,stat){

  $.ajax("DashboardCon/fetchProductCampaignData",{
          method:"POST",
          data:{year:year,product:product},
          dataType:"JSON",      
          success:function(data)
            {
                console.log("success");
                //alert(data[0].campName);        
                campaignanalysis(data,stat);                     
            },
          error: function(xhr,ajaxOptions, thrownError) 
            {
            m11.innerHTML = " No product campaign declared for this product yet";
            //alert(xhr.status);
            //alert(thrownError);
            console.log("error");
            }
          })
}


function campaignanalysis(campdata,stat){
 
  var jsonData2 = campdata;
  var jsonData = stat;
  var campName = jsonData2[0].campName;
  var campInitiation = jsonData2[0].campInitiation;
  var campStartDate = jsonData2[0].campStartDate;
  var campEndDate = jsonData2[0].campEndDate;
  var campmonth = jsonData2[0].campmonth;
  var campCost = jsonData2[0].campCost;
  

  var cumProRevenue = jsonData[0][0].cumProRevenue;
  var cumProRevenue_lastyeartailing = jsonData[5][0].cumProRevenue_lastyeartailing;
  var cumSales = jsonData[0][0].cumSales;
  var cumSales_lastyeartailing = jsonData[5][0].cumSales_lastyeartailing;
  var cxBase = jsonData[0][0].cxBase;
  var cumDis = jsonData[0][0].cumDis;
  var y2dcxbase = (cxBase+cumSales-cumDis);
  var ARPM = ((cumProRevenue+cumProRevenue_lastyeartailing)/12).toFixed(2);
  var productRevPerformance = jsonData[6][(campmonth-1)].proRevenue;
  var productSalesPerformance = jsonData[6][(campmonth-1)].mSales;
  var ASPM = ((cumSales+cumSales_lastyeartailing)/12).toFixed(2);
  var ARPU = ((cumProRevenue+cumProRevenue_lastyeartailing)*1000000/(y2dcxbase*12)).toFixed(2);

  if (productSalesPerformance>ASPM){
    if(((productSalesPerformance-ASPM)*ARPU/1000000)>campCost){
      m11.innerHTML = " Declared product campaign is effective and profitable";
      }
    else{
      m11.innerHTML = " Declared product campaign is effective, but not profitable";
     }
    
  }
  else{
    m11.innerHTML = " Declared product campaign is not effective ";
  }


  
  



}