<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		redirect('DashboardCon');
	}

	public function about()
	{
		if (!$this->session->userdata('logedin')){
			 redirect('home/login');
		}
		else{
			$this->load->view('about');
		}
	}

	public function campconfi()
	{
		if (!$this->session->userdata('logedin')){
			 redirect('home/login');
		}
		else{
			$this->load->model('DashboardMod');
			$data['product_list'] = $this->DashboardMod->fetchProData();
			$this->load->view('campconfi',$data);
		}
	}

	public function cost()
	{
		if (!$this->session->userdata('logedin')){
			 redirect('home/login');
		}
		else{
			$this->load->model('DashboardMod');
			$this->load->model('CostMod');
			$data['product_list'] = $this->DashboardMod->fetchProData();
			$data['costdata'] = $this->CostMod->loadCostData();
			$this->load->view('cost',$data);
		}
	}

	public function login()
	{
		$this->load->view('login');
	}

	public function proconfi()
	{
		if (!$this->session->userdata('logedin')){
			 redirect('home/login');
		}
		else{
			$this->load->model('ProMod');
			$data['manager_list'] = $this->ProMod->fetchManagerData();
			$this->load->view('proconfi',$data);
		}
	}

	public function progress()
	{
		if (!$this->session->userdata('logedin')){
			 redirect('home/login');
		}
		else{
			$this->load->model('DashboardMod');
			$this->load->model('ProgressMod');
			$data['product_list'] = $this->DashboardMod->fetchProData();
			$data['Progressdata'] = $this->ProgressMod->loadProgressData();
			$this->load->view('progress',$data);
		}
	}

	public function targets()
	{
		if (!$this->session->userdata('logedin')){
			 redirect('home/login');
		}
		else{
			$this->load->model('DashboardMod');
			$this->load->model('TargetMod');
			$data['product_list'] = $this->DashboardMod->fetchProData();
			$data['targetdata'] = $this->TargetMod->loadTargetData();
			$this->load->view('targets',$data);
		}
	}

	public function register()
	{
		if (!$this->session->userdata('logedin')){
			 redirect('home/login');
		}
		else{
			if ($this->session->userdata('logedin') && $this->session->userdata('admin')=='admin'){
				$this->load->view('register');
			}
			else{
				redirect('home/login');
			}
		}
	}

	public function change()
	{
		if (!$this->session->userdata('logedin')){
			 redirect('home/login');
		}
		else{
			$this->load->view('change');
		}
	}
}
