<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class LoginCon extends CI_Controller {

	public function verify (){

		$this->form_validation->set_rules('uerID', 'Service Number', 'required');
		$this->form_validation->set_rules('passWord', 'Password', 'required');

		if ($this->form_validation->run() == FALSE)
                {
                        $this->load->view('login');
                }
                else
                {
                        $this->load->model('UserMod');
                        $result = $this->UserMod->loginUser();

                        if ($result != false){
                                $user_data = array(
                                        'userID' => $result->userID, 
                                        'fName' => $result->fName,
                                        'admin' => $result->administrator,
                                        'logedin'=> TRUE
                                );

                                $this->session->set_userdata($user_data);
                                //print_r($_SESSION);
                                $this->session->set_flashdata('welcome','welcome back');
                                redirect('home/index');

                        }
                        else{
                                $this->session->set_flashdata('msg_login','Invalid username or password ');
                                redirect('home/login');
                        }
                       
                }


	}

        public  function logout(){

                $this->session->unset_userdata('logedin');
                $this->session->unset_userdata('userID');
                $this->session->unset_userdata('fName');
                $this->session->unset_userdata('admin');
                redirect('home/login');
        }
}