<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ProgressCon extends CI_Controller {

	public function progressdata(){

		$this->form_validation->set_rules('updateYear', 'Year need to update', 'required|callback_future_year_check');
		$this->form_validation->set_rules('updateMonth', 'Month need to update', 'required|callback_future_month_check['.$this->input->post('updateYear').']');
		$this->form_validation->set_rules('productID', 'Product ID', 'required');
		$this->form_validation->set_rules('productRevenue', 'Product Revenue', 'required|greater_than_equal_to[0]');
		$this->form_validation->set_rules('newConnections', 'No of New Connections', 'required|greater_than_equal_to[0]');
		$this->form_validation->set_rules('totalDisconnections', 'Total Disconnections', 'required|greater_than_equal_to[0]');
		$this->form_validation->set_rules('customerBase', 'Customer Base', 'required|greater_than_equal_to[0]');

		if ($this->form_validation->run() == FALSE)
            {
                    $this->load->view('progress');
            }
        else
	        {
                $this->load->model('ProgressMod');
                $resultdatacheck = $this->ProgressMod->checkProgressData();

                if ($resultdatacheck != false)
	                {

	                 	$this->session->set_flashdata('msg_duplicate_progressdata','This product progress data is already available  ');
	                    redirect('home/progress');


	                }
	                else{

	                	if($this->ProgressMod->checkEarlyUpdates()<($this->input->post('updateMonth')-1))
	                	{

	                		$this->session->set_flashdata('msg_absent_early_progressdata','This product progress data has not been updated for previous months');
	                    	redirect('home/progress');
	
	                	}

	                	else{

	                		$resultinsert = $this->ProgressMod->insertProgressData();

		                 	if($resultinsert != false){

		                 		$this->session->set_flashdata('msg_success_progressdata','Your product progress data updated successfully ');
		                    	redirect('home/progress');

		                 	}
	                	}
	                	


	                }

	        }

	}


	public function updateAvailableData(){

		$this->form_validation->set_rules('updateYear', 'Year need to update', 'required|callback_future_year_check');
		$this->form_validation->set_rules('updateMonth', 'Month need to update', 'required|callback_future_month_check['.$this->input->post('updateYear').']');
		$this->form_validation->set_rules('productID', 'Product ID', 'required');
		$this->form_validation->set_rules('productRevenue', 'Product Revenue', 'required');
		$this->form_validation->set_rules('newConnections', 'No of New Connections', 'required');
		$this->form_validation->set_rules('totalDisconnections', 'Total Disconnections', 'required');
		$this->form_validation->set_rules('customerBase', 'Customer Base', 'required');

		if ($this->form_validation->run() == FALSE)
            {
                    $this->load->view('progress');
            }
        else
	        {
                $this->load->model('ProgressMod');
                if($this->ProgressMod->checkEarlyUpdates()<($this->input->post('updateMonth')-1))
	                	{

	                		$this->session->set_flashdata('msg_absent_early_progressdata','This product progress data has not been updated for previous months');
	                    	redirect('home/progress');
	
	                	}

	                	else{

	                		$resultinsert = $this->ProgressMod->updateProgressData();

		                 	if($resultinsert != false){

		                 		$this->session->set_flashdata('msg_success_progressdata','Your product progress data updated successfully ');
		                    	redirect('home/progress');

		                 	}
	                	}

	        }

	}


	public function future_year_check($updateYear){

		$current_year = date('Y');
		if($updateYear>$current_year){
		 			
 			$this->form_validation->set_message('future_year_check', 'You can only update the progress of the current or past year');
 					return FALSE;
            }
        else
            {
                
 				return TRUE;
            }
	}


	public function future_month_check($updateMonth,$updateYear){

		$current_month = date('m');
		$current_year = date('Y');
		if($updateMonth>=$current_month && $current_year==$updateYear){
		 			
 			$this->form_validation->set_message('future_month_check', 'You can only update the past months');
 					return FALSE;
            }
        else
            {
                
 				return TRUE;
            }
	}

	




}