<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CostCon extends CI_Controller {

	public function costdata(){

		$this->form_validation->set_rules('productID', 'product name', 'required');
		$this->form_validation->set_rules('capexInvestment', 'CAPEX Investment', 'required|greater_than_equal_to[0]');
		$this->form_validation->set_rules('networkCost', 'Network Cost', 'required|greater_than_equal_to[0]');
		$this->form_validation->set_rules('cpeCost', 'CPE Cost', 'required|greater_than_equal_to[0]');
		$this->form_validation->set_rules('atlCost', 'ATL Marcom Cost', 'required|greater_than_equal_to[0]');
		$this->form_validation->set_rules('btlCost', 'BTL Marcom Cost', 'required|greater_than_equal_to[0]');
		$this->form_validation->set_rules('otherCost', 'Other Cost', '');

		$tempdata = array('productID' => ($this->input->post('productID')));
		$this->session->set_tempdata($tempdata, NULL, 300);

		if ($this->form_validation->run() == FALSE)
            {
                    $this->load->view('cost');
            }
        else
	        {
                $this->load->model('CostMod');
                $resultdatacheck = $this->CostMod->checkCostData();

                if ($resultdatacheck != false)
	                {

	                 	$this->session->set_flashdata('msg_duplicate_costdata','This product cost data is already available  ');
	                    redirect('home/cost');


	                }

	                else{

	                	$resultinsert = $this->CostMod->insertCostData();

	                 	if($resultinsert != false){

	                 		$this->session->set_flashdata('msg_success_costdata','Your product cost data updated successfully ');
	                    	redirect('home/cost');

	                 	}


	                }

	        }

	}


	public function updateCostData(){

		$this->form_validation->set_rules('productID', 'product name', 'required');
		$this->form_validation->set_rules('capexInvestment', 'CAPEX Investment', 'required|greater_than_equal_to[0]');
		$this->form_validation->set_rules('networkCost', 'Network Cost', 'required|greater_than_equal_to[0]');
		$this->form_validation->set_rules('cpeCost', 'CPE Cost', 'required|greater_than_equal_to[0]');
		$this->form_validation->set_rules('atlCost', 'ATL Marcom Cost', 'required|greater_than_equal_to[0]');
		$this->form_validation->set_rules('btlCost', 'BTL Marcom Cost', 'required|greater_than_equal_to[0]');
		$this->form_validation->set_rules('otherCost', 'Other Cost', '');

		$tempdata = array('productID' => ($this->input->post('productID')));
		$this->session->set_tempdata($tempdata, NULL, 300);

		if ($this->form_validation->run() == FALSE)
            {
                    $this->load->view('cost');
            }
        else
	        {
                $this->load->model('CostMod');
                $resultinsert = $this->CostMod->updateCostData();

	                 	if($resultinsert != false){

	                 		$this->session->set_flashdata('msg_success_costdata','Your product cost data updated successfully ');
	                    	redirect('home/cost');

	                 	}

	        }

	}


	public function updateData(){

		$this->load->model('CostMod');
		$resultupdate = $this->CostMod->updateCostData();

	    if($resultupdate != false){

	        $this->session->set_flashdata('msg_success_costdata','Your product cost data updated successfully ');
	        //redirect('home/cost');
	        return TRUE;
	        exit;
	    }


	}


}
