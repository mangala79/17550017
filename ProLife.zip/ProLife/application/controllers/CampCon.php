<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CampCon extends CI_Controller {

	public function campdata(){

		$this->form_validation->set_rules('productName', 'Product Name', 'required');
		$this->form_validation->set_rules('campaignName', 'Campaign Name', 'required|is_unique[campaign.campName]');
		$this->form_validation->set_rules('campInitiation', 'Campaign Initiation', 'required|greater_than_equal_to[0]');
		$this->form_validation->set_rules('campStartDate', 'Campaign Start Date', 'required|callback_check_campaign_startdate');
		$this->form_validation->set_rules('campEndtDate', 'Campaign End Date', 'required|callback_check_campaign_enddate['.$this->input->post('campStartDate').']');
		$this->form_validation->set_rules('campCost', 'Campaign Cost', 'required|greater_than_equal_to[0]');

		if ($this->form_validation->run() == FALSE)
            {
                    $this->load->view('campconfi');
            }
        else
	        {
                $this->load->model('CampMod');
                $result = $this->CampMod->insertCampData();

                if ($result != false)
	                {

	                 	$this->session->set_flashdata('msg_success_campdata','Your campaign data updated successfully ');
	                    redirect('home/campconfi');

	                }


	        }


	}


	public function check_campaign_startdate($sdate){

		$todayDate = date('Y-m-d'); // select date in Y-m-d format

		if($todayDate>$sdate){
			$this->form_validation->set_message('check_campaign_startdate', 'The {field} field can not be past date');
 					return FALSE;
		}
		else{
			return TRUE;
		}
	}


	public function check_campaign_enddate($campEndtDate,$campStartDate){

		
		if($campEndtDate<$campStartDate){
			$this->form_validation->set_message('check_campaign_enddate', 'The {field} field can not be the date before the campaign strat date');
 					return FALSE;
		}

		else{
			return TRUE;
		}
	}


}
