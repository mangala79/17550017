<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class TargetCon extends CI_Controller {

	public function targetdata(){

		$this->form_validation->set_rules('abpYear', 'ABP Year', 'required|callback_check_year');
		$this->form_validation->set_rules('productID', 'Product Name', 'required');
		$this->form_validation->set_rules('productRevenueJan', 'productRevenueJan', 'required|greater_than_equal_to[0]');
		$this->form_validation->set_rules('productRevenueFeb', 'productRevenueFeb', 'required');
		$this->form_validation->set_rules('productRevenueMar', 'productRevenueMar', 'required');
		$this->form_validation->set_rules('productRevenueApr', 'productRevenueApr', 'required');
		$this->form_validation->set_rules('productRevenueMay', 'productRevenueMay', 'required');
		$this->form_validation->set_rules('productRevenueJun', 'productRevenueJun', 'required');
		$this->form_validation->set_rules('productRevenueJul', 'productRevenueJul', 'required');
		$this->form_validation->set_rules('productRevenueAug', 'productRevenueAug', 'required');
		$this->form_validation->set_rules('productRevenueSep', 'productRevenueSep', 'required');
		$this->form_validation->set_rules('productRevenueOct', 'productRevenueOct', 'required');
		$this->form_validation->set_rules('productRevenueNov', 'productRevenueNov', 'required');
		$this->form_validation->set_rules('productRevenueDec', 'productRevenueDec', 'required');

		$this->form_validation->set_rules('newConnectionsJan', 'newConnectionsJan', 'required|greater_than_equal_to[0]');
		$this->form_validation->set_rules('newConnectionsFeb', 'newConnectionsFeb', 'required');
		$this->form_validation->set_rules('newConnectionsMar', 'newConnectionsMar', 'required');
		$this->form_validation->set_rules('newConnectionsApr', 'newConnectionsApr', 'required');
		$this->form_validation->set_rules('newConnectionsMay', 'newConnectionsMay', 'required');
		$this->form_validation->set_rules('newConnectionsJun', 'newConnectionsJun', 'required');
		$this->form_validation->set_rules('newConnectionsJul', 'newConnectionsJul', 'required');
		$this->form_validation->set_rules('newConnectionsAug', 'newConnectionsAug', 'required');
		$this->form_validation->set_rules('newConnectionsSep', 'newConnectionsSep', 'required');
		$this->form_validation->set_rules('newConnectionsOct', 'newConnectionsOct', 'required');
		$this->form_validation->set_rules('newConnectionsNov', 'newConnectionsNov', 'required');
		$this->form_validation->set_rules('newConnectionsDec', 'newConnectionsDec', 'required');

		$this->form_validation->set_rules('disConnectionsJan', 'disConnectionsJan', 'required|greater_than_equal_to[0]');
		$this->form_validation->set_rules('disConnectionsFeb', 'disConnectionsFeb', 'required');
		$this->form_validation->set_rules('disConnectionsMar', 'disConnectionsMar', 'required');
		$this->form_validation->set_rules('disConnectionsApr', 'disConnectionsApr', 'required');
		$this->form_validation->set_rules('disConnectionsMay', 'disConnectionsMay', 'required');
		$this->form_validation->set_rules('disConnectionsJun', 'disConnectionsJun', 'required');
		$this->form_validation->set_rules('disConnectionsJul', 'disConnectionsJul', 'required');
		$this->form_validation->set_rules('disConnectionsAug', 'disConnectionsAug', 'required');
		$this->form_validation->set_rules('disConnectionsSep', 'disConnectionsSep', 'required');
		$this->form_validation->set_rules('disConnectionsOct', 'disConnectionsOct', 'required');
		$this->form_validation->set_rules('disConnectionsNov', 'disConnectionsNov', 'required');
		$this->form_validation->set_rules('disConnectionsDec', 'disConnectionsDec', 'required');
		$this->form_validation->set_rules('customerBase', 'customerBase', '');

		if ($this->form_validation->run() == FALSE)
            {
                    $this->load->view('targets');
            }
        else
	        {
                $this->load->model('TargetMod');
                $resultdatacheck = $this->TargetMod->checkTargetData();

                if ($resultdatacheck != false)
	                {

	                 	$this->session->set_flashdata('msg_dupplicate_targetdata','This product target data is already updated  ');
	                    redirect('home/targets');


	                }

	                else{

	                	$resultinsert = $this->TargetMod->insertTargetData();

	                 	if($resultinsert != false){

	                 		$this->session->set_flashdata('msg_success_targetdata','Your product target data updated successfully ');
	                    	redirect('home/targets');

	                 	}


	                }

	        }

	}




	public function check_year($abpYear){

		//this function check the updatebele period . Only 90 days prior to ABP year is allowed 

		$current_year=date('Y');
		if (($current_year==$abpYear)||($current_year<$abpYear && ($current_year==($abpYear-1)))){

			if($current_year==$abpYear){
				return TRUE;
			}

			else{

				$todayDate = date('Y-m-d'); // select date in Y-m-d format
				$allowedDate = new DateTime($todayDate);
				$allowedDate->add(new DateInterval('P90D')); // P90D means a period of 90 day
				$alloweddate = $allowedDate->format('Y');


		 		if($abpYear>$alloweddate){
		 			
		 			$this->form_validation->set_message('check_year', 'ABP targets can be updated only 90 days prior to the ABP year');
		 					return FALSE;
		            }
	            else
		            {
		                
		 				return TRUE;
		            }
			}

			

		}

		else{

			$this->form_validation->set_message('check_year', 'The {field} field has to be this year or next year');
 					return FALSE;
		}

	}

}
