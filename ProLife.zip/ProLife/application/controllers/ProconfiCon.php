<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ProconfiCon extends CI_Controller {

	public function prodata(){

		$this->form_validation->set_rules('productName', 'Product Name', 'required|is_unique[product.proName]');
		$this->form_validation->set_rules('productdescription', 'Product Description', 'required');
		$this->form_validation->set_rules('launchedDate', 'launched Date', 'required|callback_check_launched_date');
		$this->form_validation->set_rules('Strategy', 'Strategy', 'required');
		$this->form_validation->set_rules('noofCompetitors', 'No of Competitors', 'required');
		$this->form_validation->set_rules('proInitiation', 'Product Initiation Fee', 'required|greater_than_equal_to[0]');
		$this->form_validation->set_rules('mRental', 'Monthly Rental', 'required|greater_than_equal_to[0]');
		$this->form_validation->set_rules('peekOnNet', 'On Net Peek chargers');
		$this->form_validation->set_rules('peekOffNet', 'Off Net Peek chargers');
		$this->form_validation->set_rules('offPeekOnNet', 'On Net Offpeek chargers');
		$this->form_validation->set_rules('offPeekOffNet', 'Off Net Offpeek chargers');


		if ($this->form_validation->run() == FALSE)
            {
                    $this->load->view('proconfi');
            }
        else
	        {
                $this->load->model('ProMod');
                $result = $this->ProMod->insertProData();

                if ($result != false)
	                {

	                 	$this->session->set_flashdata('msg_success_prodata','Your campaign data updated successfully ');
	                    redirect('home/proconfi');

	                }


	        }

	}


	public function check_launched_date($ldate){

		$startDate = date('Y-m-d'); // select date in Y-m-d format
		$newstartDate = new DateTime($startDate);
		$newstartDate->add(new DateInterval('P90D')); // P90D means a period of 90 day
		$alloweddate = $newstartDate->format('Y-m-d');

		
		//echo($ldate);
		//echo($alloweddate);


 		if($ldate>$alloweddate){
 			
 			$this->form_validation->set_message('check_launched_date', 'The {field} field can not be advanced more than 90 days');
 					return FALSE;
            }
        else
	        {
	            
					return TRUE;
	        }
 	}


}