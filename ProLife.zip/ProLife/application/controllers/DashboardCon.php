<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class DashboardCon extends CI_Controller {

	public function __construct()
		{
			/**
			* This will checks the availability of userdata('logedin')
			* If it is not available, it will redirect to the 'login' page
			* If it is is available it will load the model;'dashboard_chart_model' by default
			*/
			parent::__construct();
			if(!$this->session->userdata('logedin'))
			{
			redirect('Home/login');
			}
			else
			{
				$this->load->model('DashboardMod');
			}
			
			
		}

	public function index()
		{

			$data['year_list'] = $this->DashboardMod->fetchYearData();
			$data['product_list'] = $this->DashboardMod->fetchProData();
			$data['manager_list'] = $this->DashboardMod->fetchManagerData();
			$this->load->view('Dashboard',$data);
		}

	public function fetchSummaryData()
		{
			/**
			* This function check the availability of the values for 'year' 
			* & fetch the data from SQL db by calling relevent model (DashboardMod)
			* Finaly data will be encoded for JSON data format
			*/


			if($this->input->post('year'))

			{
			   	//$_SESSION['form_data1'] = $_POST;
			   	$tempdata = array('year' => ($this->input->post('year')));
				$this->session->set_tempdata($tempdata, NULL, 300);


				$chart_data = $this->DashboardMod->fetchPerformcanceData($this->input->post('year'));
			   
			   	foreach($chart_data->result_array() as $row)
				   	{
					    $output[] = array(
					    'proName'  => $row["proName"],
					    'cumProRevenue' => floatval($row["proRevenue"]),
					 	'CumMSales' => floatval($row["mSales"]),
					 	'CumDis' => floatval($row["mDis"]),
					 	'CumRevTar' => floatval($row["mRevTar"]));
				    }

			    
			    echo json_encode($output);
			    //print_r($output);
		  	}

		  	
		}

	public function fetchManagerData()
		{
			/**
			* This function check the availability of the values for 'year' 
			* & fetch the data from SQL db by calling relevent model (DashboardMod)
			* Finaly data will be encoded for JSON data format
			*/


			if($this->input->post('manager'))

			{
			   	//$_SESSION['form_data1'] = $_POST;
			   	$tempdata2 = array('manager' => ($this->input->post('manager')));
				$this->session->set_tempdata($tempdata2, NULL, 300);


				$chart_data = $this->DashboardMod->fetchPerformcanceData($this->input->post('year'));
			   
			   	foreach($chart_data->result_array() as $row)
				   	{
					    $output[] = array(
					    'proName'  => $row["proName"],
					    'cumProRevenue' => floatval($row["proRevenue"]),
					 	'CumMSales' => floatval($row["mSales"]),
					 	'CumDis' => floatval($row["mDis"]),
					 	'CumRevTar' => floatval($row["mRevTar"]));
				    }

			    
			    echo json_encode($output);
			    //print_r($output);
		  	}

		  	
		}

	public function fetchKPISummaryData()
		{
			/**
			* This function check the availability of the values for 'year' 
			* & fetch the data from SQL db by calling relevent model (DashboardMod)
			* Finaly data will be encoded for JSON data format
			* This will be used to show aggregated KPI on dashboard loading
			*/


			if($this->input->post('year'))

			{
			   
				$KPI_data = $this->DashboardMod->fetchKPIData($this->input->post('year'));
			   
			   	foreach($KPI_data['currentaggri']->result_array() as $row)
				   	{
					    $output1[] = array(
					    'AggregatedCumRev' => floatval($row["AggregatedCumRev"]),
					 	'AggregatedCumSales' => floatval($row["AggregatedCumSales"]),
					 	'AggregatedCumDis' => floatval($row["AggregatedCumDis"]),
					 	'AggregatedCumRevenueTar' => floatval($row["AggregatedCumRevenueTar"]),
					 	'AggregatedCumSalesTar' => floatval($row["AggregatedCumSalesTar"]),
					 	'AggregatedCumDisTar' => floatval($row["AggregatedCumDisTar"]));
				    }


				foreach($KPI_data['yearbeforeaggri']->result_array() as $row)
				   	{
					    $output2[] = array(
					    'AggregatedCumProRevenue_yearbefore' => floatval($row["AggregatedCumProRevenue_yearbefore"]),
					 	'AggregatedCumSales_yearbefore' => floatval($row["AggregatedCumSales_yearbefore"]),
					 	'AggregatedCumDis_yearbefore' => floatval($row["AggregatedCumDis_yearbefore"]));
					 	
				    }

				foreach($KPI_data['trailingmonthaggri']->result_array() as $row)
				   	{
					    $output3[] = array(
					    'AggregatedCumProRevenue_lastyeartailing' => floatval($row["AggregatedCumProRevenue_lastyeartailing"]),
					 	'AggregatedCumSales_lastyeartailing' => floatval($row["AggregatedCumSales_lastyeartailing"]),
					 	'AggregatedCumDis_lastyeartailing' => floatval($row["AggregatedCumDis_lastyeartailing"]));
					 	
				    }

			    
			    echo json_encode([$output1,$output2,$output3]);
			    //print_r($output);
		  	}

		  	
		}

	public function fetchProductData()
		{
			/**
			* This function check the availability of the values for 'year' 
			* & fetch the data from SQL db by calling relevent model (DashboardMod)
			* Finaly data will be encoded for JSON data format
			*/


			if($this->input->post('year') && $this->input->post('product') )

			{
			   	//$_SESSION['form_data1'] = $_POST;
				$chart_data = $this->DashboardMod->fetchProPerformcanceData($this->input->post('year'),$this->input->post('product'));
			   
			   	foreach($chart_data->result_array() as $row)
				   	{
					    $output[] = array(
					    'month'  => $row["month"],
					    'proRevenue' => floatval($row["proRevenue"]),
					 	'mSales' => floatval($row["mSales"]),
					 	'mDis' => floatval($row["mDis"]),
					 	'cxBase' => floatval($row["cxBase"]),
					 	'mRevTar' => floatval($row["mRevTar"]),
					 	'mSalesTar' => floatval($row["mSalesTar"]),	
					 	'mDisTar' => floatval($row["mDisTar"]),
					 	'cxBaseTar' => floatval($row["cxBaseTar"])
					 );
				    }

			    
			    echo json_encode($output);
			    //print_r($output);
		  	}

		  	
		}

	public function fetchProductSummaryData()
		{
			/**
			* This function check the availability of the values for 'year' 
			* & fetch the data from SQL db by calling relevent model (DashboardMod)
			* Finaly data will be encoded for JSON data format
			*/


			if($this->input->post('year') && $this->input->post('product') )

			{
			   	//$_SESSION['form_data1'] = $_POST;
			   	$tempdata = array('year' => ($this->input->post('year')), 'product' => ($this->input->post('product')),'manager' => ($this->input->post('manager')));
				$this->session->set_tempdata($tempdata, NULL, 300);

				$chart_data = $this->DashboardMod->fetchProPerformcanceSummary($this->input->post('year'),$this->input->post('product'));
			   
			   	foreach($chart_data['thisyear']->result_array() as $row)
				   	{
					    $output1[] = array(
					    'cumProRevenue' => floatval($row["cumProRevenue"]),
					 	'cumSales' => floatval($row["cumSales"]),
					 	'cumDis' => floatval($row["cumDis"]),
					 	'cxBase' => floatval($row["cxBase"]),
					 	'cumRevenueTar' => floatval($row["cumRevenueTar"]),
					 	'cumSalesTar' => floatval($row["cumSalesTar"]),	
					 	'cumDisTar' => floatval($row["cumDisTar"]),
					 	'cxBaseTar' => floatval($row["cxBaseTar"]),

					 						 );
				    }

				foreach($chart_data['lastyear']->result_array() as $row)
				   	{
					    $output2[] = array(
					    'cumProRevenue_yearbefore' => floatval($row["cumProRevenue_yearbefore"]),
					 	'cumSales_yearbefore' => floatval($row["cumSales_yearbefore"]),
					 	'cumDis_yearbefore' => floatval($row["cumDis_yearbefore"]),
					 	'cxBase_yearbefore' => floatval($row["cxBase_yearbefore"]),
					 						 );
				    }


				foreach($chart_data['3yearsbefore']->result_array() as $row)
				   	{
					    $output3[] = array(
					    'cumProRevenue_3yearbefore' => floatval($row["cumProRevenue_3yearbefore"]),
					 	'cumSales_3yearbefore' => floatval($row["cumSales_3yearbefore"]),
					 	'cumDis_3yearbefore' => floatval($row["cumDis_3yearbefore"]),
					 	'cxBase_3yearbefore' => floatval($row["cxBase_3yearbefore"]),
					 						 );
				    }


				foreach($chart_data['prodata']->result_array() as $row)
				   	{
					    $output4[] = array(
					    'proName' => $row["proName"],
					 	'launchDate' => floatval($row["launchDate"])
					 	);
				    }


				foreach($chart_data['Aggregateddata']->result_array() as $row)
				   	{
					    $output5[] = array(
					    'AggregatedCumRev' => floatval($row["AggregatedCumRev"]),
					 	'AggregatedCumSales' => floatval($row["AggregatedCumSales"]),
					 	'AggregatedCumDis' => floatval($row["AggregatedCumDis"]),
					 	);
				    }


				foreach($chart_data['lastyeartailingdata']->result_array() as $row)
				   	{
					    $output6[] = array(
					    'cumProRevenue_lastyeartailing' => floatval($row["cumProRevenue_lastyeartailing"]),
					 	'cumSales_lastyeartailing' => floatval($row["cumSales_lastyeartailing"]),
					 	'cumDis_lastyeartailing' => floatval($row["cumDis_lastyeartailing"]),
					 	'cxBase_lastyeartailing' => floatval($row["cxBase_lastyeartailing"]),
					 						 );
				    }


				foreach($chart_data['currentproperformance']->result_array() as $row)
				   	{
					    $output7[] = array(
					    'month' => $row["month"],
					 	'proRevenue' => floatval($row["proRevenue"]),
					 	'cxBase' => floatval($row["cxBase"]),
					 	'mSales' => floatval($row["mSales"]),
					 	'mDis' => floatval($row["mDis"])
					 						 );
				    }

			    

					$outputdata = array($output1,$output2,$output3,$output4,$output5,$output6,$output7);
					
				
			    
			    echo json_encode($outputdata);
			    //echo json_encode($output2);
			    //print_r($output);
		  	}

		  	
		}

	public function fetchProductCampaignData(){


			if($this->input->post('year') && $this->input->post('product') )

			{
			   	$this->load->model('CampMod');
			   	$campaign_data = $this->CampMod->fetchProCampaign($this->input->post('year'),$this->input->post('product'));

			   	foreach($campaign_data->result_array() as $row)
				   	{
					    $output[] = array(
					    'campID'  => $row["campID"],
					    'campName' => $row["campName"],
					 	'campInitiation' => floatval($row["campInitiation"]),
					 	'campStartDate' => $row["campStartDate"],
					 	'campEndDate' => $row["campEndDate"],
					 	'campCost' => floatval($row["campCost"]),
					 	'campmonth' => floatval($row["month"])

					 );
				    }

				echo json_encode($output);


			}


	}

	public function exportCSV()
	  { 

	  	if ($this->session->tempdata('product')){

		  	//echo($this->session->tempdata('year'));
		  	//echo($this->session->tempdata('product'));
		  	

		   
		   	// file name 
		   	$filename = 'Source data for'.$_SESSION['product']. 'performance visualization for year'.$_SESSION['year'].'.csv';  
		   	header("Content-Description: File Transfer"); 
		   	header("Content-Disposition: attachment; filename=$filename"); 
		   	header("Content-Type: application/csv; ");
		   	//echo "test CSV";

	   
	   	

			// get data 
		   $chartData = $this->DashboardMod->fetchProPerformcanceData($this->session->tempdata('year'),$this->session->tempdata('product'));
		   

		   // file creation 
		   
		   $file = fopen('php://output', 'w');
		 
		   $header = array("month","proRevenue","mSales","mDis","cxBase","mRevTar","mSalesTar","mDisTar","cxBaseTar");

	 
		   fputcsv($file, $header);
		   $data = $chartData->result_array();
		   foreach ($data as $line){
		   	//echo "<script>alert('$line');</script>";
		   	fputcsv($file,$line); 
		   }
		   fclose($file);
		   unset($_SESSION['year']);
		   unset($_SESSION['product']);
		   exit; 
		}
		else{
			
			// file name 
		   	$filename = 'Source data for product summary visualization for year'.$_SESSION['year'].'.csv';  
		   	header("Content-Description: File Transfer"); 
		   	header("Content-Disposition: attachment; filename=$filename"); 
		   	header("Content-Type: application/csv; ");
		   	//echo "test CSV";

		   
		   	

			// get data 
		   $chartData = $this->DashboardMod->fetchPerformcanceData($this->session->tempdata('year'));
		   

		   // file creation 
		   
		   $file = fopen('php://output', 'w');
		 
		   $header = array("proID","proName","proRevenue","mSales","mDis","mRevTar","mSalesTar","mDisTar");

	 
		   fputcsv($file, $header);
		   $data = $chartData->result_array();
		   foreach ($data as $line){
		   	//echo "<script>alert('$line');</script>";
		   	fputcsv($file,$line); 
		   }
		   fclose($file);
		   unset($_SESSION['year']); 
		   exit; 
		}

		
	  } 

}

	