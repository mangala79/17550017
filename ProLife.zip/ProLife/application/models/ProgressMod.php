<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ProgressMod extends CI_Model {


	public function checkProgressData(){

		//This will check the availability of data in database
		//This is to avoid the overwrite without knowledge of the user 

		$year = $this->input->post('updateYear');
		$month = $this->input->post('updateMonth');
		$proid = $this->input->post('productID');
		$sql = "SELECT * FROM productperformance WHERE year = ? AND month = ? AND proID = ?";
		$responceProgressData = $this->db->query($sql, array($year,$month,$proid));

		if ($responceProgressData->num_rows()==1){
			return $responceProgressData->row(0);
			
			}
			else {
				return false;

				}
			
	}


	public function checkEarlyUpdates(){

		$year = $this->input->post('updateYear');
		$month = $this->input->post('updateMonth');
		$proid = $this->input->post('productID');
		$this->db->select('*');
		$this->db->from('productperformance');
		$this->db->where('year',$year);
		$this->db->where('month <',$month);
		$this->db->where('proID',$proid);
		$progressDataCount = $this->db->count_all_results();
		return $progressDataCount;

	}



	public function insertProgressData(){

		// This function will update the produt progress data 

		$progressdata =[

		'proID' => $this->input->post('productID',TRUE),
		'year' => $this->input->post('updateYear',TRUE), 
		'month' => $this->input->post('updateMonth',TRUE),
		'proRevenue' => $this->input->post('productRevenue',TRUE),
		'mSales' => $this->input->post('newConnections',TRUE),
		'mDis' => $this->input->post('totalDisconnections',TRUE),
		'cxBase' => $this->input->post('customerBase',TRUE)
		];

		return $this->db->insert('productperformance',$progressdata);
	}


	public function loadProgressData(){

		//This will load the progree data in database
		//This is to check the available data for missing updates 

		$year = date('Y');
		$this->db->select('*');
		$this->db->from('productperformance');
		$this->db->where('year',$year);
		return $this->db->get();

	
	}


	public function updateProgressData(){

		// This function will update the produt progress data 

		$proID = $this->input->post('productID');
		$year = $this->input->post('updateYear'); 
		$month = $this->input->post('updateMonth');

		$progressdata =[

		'proRevenue' => $this->input->post('productRevenue',TRUE),
		'mSales' => $this->input->post('newConnections',TRUE),
		'mDis' => $this->input->post('totalDisconnections',TRUE),
		'cxBase' => $this->input->post('customerBase',TRUE)
		];

		$this->db->where('proID', $proID);
		$this->db->where('year', $year);
		$this->db->where('month', $month);
		return $this->db->update('productperformance',$progressdata);
	}


}