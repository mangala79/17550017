<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class DashboardMod extends CI_Model {

	public function fetchProData(){

		$this->db->select('*');
		$this->db->from('product');
		$this->db->group_by('proID');
		$this->db->order_by('proID','DESC');
		return $this->db->get();

	}


	public function fetchYearData(){

		$this->db->select('year');
		$this->db->from('productperformance');
		$this->db->group_by('year');
		$this->db->order_by('year','DESC');
		return $this->db->get();
	
	}

	public function fetchManagerData(){

		$this->db->select('fName');
		$this->db->select('userID');
		$this->db->from('productmanager');
		$this->db->group_by('fName');
		$this->db->order_by('fName','DESC');
		return $this->db->get();
	
	}

	function fetchPerformcanceData($year)
	{
		
		$this->db->select('pof.proID');
		$this->db->select('pro.proName');
		$this->db->select_sum('pof.proRevenue');
		$this->db->select_sum('pof.mSales');
		$this->db->select_sum('pof.mDis');
		$this->db->select_sum('tar.mRevTar');
		$this->db->select_sum('tar.mSalesTar');
		$this->db->select_sum('tar.mDisTar');
		$this->db->from('productperformance as pof');
		$this->db->join('product as pro','pro.proID=pof.proID','INNER');
		$this->db->join('producttargets as tar','tar.proID=pof.proID AND tar.year=pof.year AND tar.month=pof.month', 'left');
		$this->db->where('pof.year',$year);
		$this->db->group_by('pof.proID');  
		//Need to check "order_by" 
		return $this->db->get();;
	}

	function fetchKPIData($year)
	{
		if($year==date('Y'))
			{
			$month = date('m');
			}
		else
			{
			$month = 13;
			}


		$this->db->trans_start();
		// Query1 - For aggregated performance of current year
		$this->db->select('sum(pof.proRevenue) AS AggregatedCumRev'); 
		$this->db->select('sum(pof.mSales) AS AggregatedCumSales');  
		$this->db->select('sum(pof.mDis) AS AggregatedCumDis'); 
		$this->db->select('sum(tar.mRevTar) AS AggregatedCumRevenueTar');  
		$this->db->select('sum(tar.mSalesTar) AS AggregatedCumSalesTar');  
		$this->db->select('sum(tar.mDisTar) AS AggregatedCumDisTar');  
		$this->db->from('productperformance as pof');
		$this->db->join('producttargets as tar','tar.proID=pof.proID AND tar.year=pof.year AND tar.month=pof.month', 'left'); 
		$this->db->where('pof.year',$year);
		$query1 = $this->db->get(); 
		// Query2 - For Aggregated cumulative performance of one year before
		$this->db->select('sum(proRevenue) AS AggregatedCumProRevenue_yearbefore'); 
		$this->db->select('sum(mSales) AS AggregatedCumSales_yearbefore');  
		$this->db->select('sum(mDis) AS AggregatedCumDis_yearbefore');  
		$this->db->from('productperformance');
		$this->db->where('year',($year-1));
		$this->db->where('month <', $month);
		$query2 = $this->db->get();
		// Query6 - Aggregated  performance of tailing months of last year to calcuate last 12 months
		$this->db->select('sum(proRevenue) AS AggregatedCumProRevenue_lastyeartailing'); 
		$this->db->select('sum(mSales) AS AggregatedCumSales_lastyeartailing');  
		$this->db->select('sum(mDis) AS AggregatedCumDis_lastyeartailing');  
		$this->db->from('productperformance');
		$this->db->where('year',($year-1));
		$this->db->where('month >=', $month);
		$query3 = $this->db->get();
		$this->db->trans_complete();
		return array('currentaggri' => $query1,'yearbeforeaggri' => $query2, 'trailingmonthaggri' => $query3);
	}


	function fetchProPerformcanceData($year,$product)
	{
		$this->db->select('pof.month');
		$this->db->select('pof.proRevenue');
		$this->db->select('pof.mSales');
		$this->db->select('pof.mDis');
		$this->db->select('pof.cxBase');	
		$this->db->select('tar.mRevTar');
		$this->db->select('tar.mSalesTar');
		$this->db->select('tar.mDisTar');
		$this->db->select('tar.cxBaseTar');
		$this->db->select('tar.cxBaseTar');
		$this->db->from('productperformance as pof');
		$this->db->join('producttargets as tar','tar.proID=pof.proID AND tar.year=pof.year AND tar.month=pof.month', 'left');
		$this->db->where('pof.year',$year);
		$this->db->where('pof.ProID',$product);
		$this->db->order_by('pof.month', 'ASE');  
		//Need to check "order_by" 
		return $this->db->get();
	}


	function fetchProPerformcanceSummary($year,$product)
	{
		
		if($year==date('Y'))
			{
			$month = date('m');
			}
		else
			{
			$month = 13;
			}


		//$month = date('m');
		
		$this->db->trans_start();
		// Query1 - For cumulative product performance of current year
		$this->db->select('sum(pof.proRevenue) AS cumProRevenue'); 
		$this->db->select('sum(pof.mSales) AS cumSales');  
		$this->db->select('sum(pof.mDis) AS cumDis');  
		$this->db->select('pof.cxBase');
		$this->db->select('sum(tar.mRevTar) AS cumRevenueTar');  
		$this->db->select('sum(tar.mSalesTar) AS cumSalesTar');  
		$this->db->select('sum(tar.mDisTar) AS cumDisTar');  
		$this->db->select('tar.cxBaseTar');
		$this->db->select('pro.proName');
		$this->db->from('productperformance as pof');
		$this->db->join('product as pro','pro.proID=pof.proID','left');
		$this->db->join('producttargets as tar','tar.proID=pof.proID AND tar.year=pof.year AND tar.month=pof.month', 'left');
		$this->db->where('pof.year',$year);
		$this->db->where('pof.proID',$product);
		$query1 = $this->db->get(); 
		// Query2 - For cumulative product performance of one year before
		$this->db->select('sum(proRevenue) AS cumProRevenue_yearbefore'); 
		$this->db->select('sum(mSales) AS cumSales_yearbefore');  
		$this->db->select('sum(mDis) AS cumDis_yearbefore');  
		$this->db->select('cxBase AS cxBase_yearbefore');
		$this->db->from('productperformance');
		$this->db->where('year',($year-1));
		$this->db->where('month <', $month);
		$this->db->where('proID',$product);
		//Need to check "order_by" 
		$query2 = $this->db->get();
		// Query3 - For cumulative product performance of three years before
		$this->db->select('sum(proRevenue) AS cumProRevenue_3yearbefore'); 
		$this->db->select('sum(mSales) AS cumSales_3yearbefore');  
		$this->db->select('sum(mDis) AS cumDis_3yearbefore');  
		$this->db->select('cxBase AS cxBase_3yearbefore');
		$this->db->from('productperformance');
		$this->db->where('year',($year-3));
		$this->db->where('month <', $month);
		$this->db->where('proID',$product);
		//Need to check "order_by" 
		$query3 = $this->db->get();
		// Query4 - For product details
		$this->db->select('proName');  
		$this->db->select('launchDate');
		$this->db->from('product');
		$this->db->where('proID',$product);
		$query4 = $this->db->get();
		// Query5 - Aggregated performance of the year
		$this->db->select('sum(pof.proRevenue) AS AggregatedCumRev'); 
		$this->db->select('sum(pof.mSales) AS AggregatedCumSales');  
		$this->db->select('sum(pof.mDis) AS AggregatedCumDis');  
		$this->db->from('productperformance as pof');
		$this->db->where('pof.year',$year);
		$query5 = $this->db->get();
		// Query6 - product performance of tailing months of last year to calcuate last 12 months
		$this->db->select('sum(proRevenue) AS cumProRevenue_lastyeartailing'); 
		$this->db->select('sum(mSales) AS cumSales_lastyeartailing');  
		$this->db->select('sum(mDis) AS cumDis_lastyeartailing');  
		$this->db->select('cxBase AS cxBase_lastyeartailing');
		$this->db->from('productperformance');
		$this->db->where('year',($year-1));
		$this->db->where('month >=', $month);
		$this->db->where('proID',$product);
		$query6 = $this->db->get();
		// Query7 - Check the current year product performance
		$this->db->SELECT('*');
		$this->db->from('productperformance');
		$this->db->where('year',$year);
		$this->db->where('proID',$product);
		$query7 = $this->db->get();

		$this->db->trans_complete();
		return array('thisyear' => $query1, 'lastyear' => $query2, '3yearsbefore' => $query3,'prodata' => $query4, 'Aggregateddata' => $query5, 'lastyeartailingdata' => $query6, 'currentproperformance' => $query7);
	}


}