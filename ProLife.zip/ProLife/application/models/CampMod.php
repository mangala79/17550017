<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CampMod extends CI_Model {

	public function insertCampData ()
	{
		// This function will insert the campaign data 

		$data =[

		'proID' => $this->input->post('productName',TRUE),
		'campName' => $this->input->post('campaignName',TRUE), 
		'campInitiation' => $this->input->post('campInitiation',TRUE),
		'campStartDate' => $this->input->post('campStartDate',TRUE),
		'campEndDate' => $this->input->post('campEndtDate',TRUE),
		'campCost' => $this->input->post('campCost',TRUE),
		
		];

		
		return $this->db->insert('campaign',$data);
	}


	public function fetchProCampaign($year,$product){

		$this->db->SELECT('*');
		$this->db->SELECT('MONTH(campStartDate) AS month');
		$this->db->from('campaign');
		$this->db->where (('YEAR(campStartDate)'),$year);
		$this->db->where('proID',$product);
		return $this->db->get();
	}


}