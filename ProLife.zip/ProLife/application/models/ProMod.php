<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ProMod extends CI_Model {

	public function insertProData(){

		// This function will insert new produt data 

		$prodata =[

		'proName' => $this->input->post('productName',TRUE),
		'proDescription' => $this->input->post('productdescription',TRUE),
		'proManager' => $this->input->post('productManagerName',TRUE), 
		'launchDate' => $this->input->post('launchedDate',TRUE),
		'proStrategy' => $this->input->post('Strategy',TRUE),
		'NoComp' => $this->input->post('noofCompetitors',TRUE),
		'ProInitiation' => $this->input->post('proInitiation',TRUE),
		'mRental' => $this->input->post('mRental',TRUE),
		'Peek_onNet' => $this->input->post('peekOnNet',TRUE),
		'Peek_offNet' => $this->input->post('peekOffNet',TRUE),
		'offPeek_onNet' => $this->input->post('offPeekOnNet',TRUE),
		'offPeek_offNet' => $this->input->post('offPeekOffNet',TRUE),
		
		];

		return $this->db->insert('product',$prodata);
	}

	public function fetchManagerData(){

		$this->db->select('*');
		$this->db->from('productmanager');
		$this->db->group_by('userID');
		$this->db->order_by('userID','DESC');
		return $this->db->get();

	}

}