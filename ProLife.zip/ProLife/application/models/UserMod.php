<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class UserMod extends CI_Model {

	function insertdata(){

		/*
		*This function used to registr the new users
		*/

		$data =[

		'fName' => $this->input->post('FirstName',TRUE),
		'lName' => $this->input->post('LastName',TRUE), 
		'userID' => $this->input->post('uerID',TRUE),
		'administrator' => $this->input->post('admin'),  
		'Password' => md5($this->input->post('RegPassword',TRUE))
		];

		
		return $this->db->insert('productmanager',$data);

		//print_r($data);
		//die();

	}

	function loginUser(){

		/*
		*This function used to check the user login data
		*If exist need to create session
		*Else error will appear 
		*/

		$userID = $this->input->post('uerID');
		$Password = md5($this->input->post('passWord',TRUE));

		$sql = "SELECT * FROM productmanager WHERE userID = ? AND Password = ?";
		$response = $this->db->query($sql, array($userID, $Password));

		//$this->db->where('userID'= $userID);
		//$this->db->where('Password'=$Password);

		//$response = $this->db->get('productmanager');
		if ($response->num_rows()==1){
			return $response->row(0);
			
			}
			else {
				return false;

			}


	}

	function userValidate(){

		/*
		*This function used to validate the user
		*/

		$userID = $this->session->userdata('userID');
		$Password = md5($this->input->post('OldPassword',TRUE));

		$sql = "SELECT * FROM productmanager WHERE userID = ? AND Password = ?";
		$uservalidation = $this->db->query($sql, array($userID, $Password));

		
		if ($uservalidation->num_rows()==1){
			return $uservalidation->row(0);
			
			}
			else {
				return false;

			}


	}

	function updatePassword(){

		/*
		*This function used to replace the existing password with new one
		*/

		$userID = $this->session->userdata('userID');
		$Password = md5($this->input->post('newPassword'));
		
		$this->db->set('Password', $Password);
		$this->db->where('userID', $userID);
		$this->db->update('productmanager'); 

		//print_r($data);
		//die();

	}






	
}