<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CostMod extends CI_Model {

	public function insertCostData(){

		// This function will update the produt cost data 

		$costdata =[

		'proID' => $this->input->post('productID',TRUE),
		'CAPEX' => $this->input->post('capexInvestment',TRUE), 
		'nwCost' => $this->input->post('networkCost',TRUE),
		'cpeCost' => $this->input->post('cpeCost',TRUE),
		'atlCost' => $this->input->post('atlCost',TRUE),
		'btlCost' => $this->input->post('btlCost',TRUE),
		'otherCost' => $this->input->post('otherCost',TRUE)
		
		];

		return $this->db->insert('productcost',$costdata);
	}

	public function checkCostData(){

		//This will check the availability of data in database
		//This is to avoid the overwrite without knowledge of the user 

		$proid = $this->input->post('productID');
		$sql = "SELECT * FROM productcost WHERE proID = ? ";
		$responceCostData = $this->db->query($sql, $proid);

		if ($responceCostData->num_rows()==1){
			return $responceCostData->row(0);
			
			}
			else {
				return false;

				}
			
	}


	public function updateCostData(){

		// This function will update the produt cost data 

		$proID = $this->input->post('productID');

		$costdata =[

		'CAPEX' => $this->input->post('capexInvestment',TRUE), 
		'nwCost' => $this->input->post('networkCost',TRUE),
		'cpeCost' => $this->input->post('cpeCost',TRUE),
		'atlCost' => $this->input->post('atlCost',TRUE),
		'btlCost' => $this->input->post('btlCost',TRUE),
		'otherCost' => $this->input->post('otherCost',TRUE)
		
		];

		$this->db->where('proID', $proID);
		return $this->db->update('productcost',$costdata);
	}



	public function loadCostData(){

		//This will check the availability of data in database
		//This is to avoid the overwrite without knowledge of the user 

		$this->db->select('*');
		$this->db->from('productcost');
		return $this->db->get();
		}	
}