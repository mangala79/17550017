<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class TargetMod extends CI_Model {

	public function checkTargetData(){

		//This will check the availability of the target in database for same ABP year
		//This is to avoid the overwrite without knowledge of the user 

		$year = $this->input->post('abpYear');
		$proID = $this->input->post('productID');

		
		$sql = "SELECT * FROM producttargets WHERE year = ? AND proID = ? AND month = ?";
		$responceTargetData = $this->db->query($sql, array($year,$proID, '1'));

		if ($responceTargetData->num_rows()==1){
			return $responceTargetData->row(0);
			
			}
			else {
				return false;

				}				
			
	}


	public function insertTargetData(){

		/*
		* used to inser the ABP target enter in annual target window (home/target)
		* second argument of the post method set to "TRUE" to enebale security feature.
		* This featue; "global_xss_filtering" is enabled in config.php file in config folder
		*/

		
		
		$abpTarget = [

			['proID' => $this->input->post('productID',TRUE),
			'year' => $this->input->post('abpYear',TRUE),
			'month' => '1',
			'mRevTar' => $this->input->post('productRevenueJan',TRUE),
			'mSalesTar' => $this->input->post('newConnectionsJan',TRUE),
			'mDisTar' => $this->input->post('disConnectionsJan',TRUE),
			 ],

			 ['proID' => $this->input->post('productID',TRUE),
			'year' => $this->input->post('abpYear',TRUE),
			'month' => '2',
			'mRevTar' => $this->input->post('productRevenueFeb',TRUE),
			'mSalesTar' => $this->input->post('newConnectionsFeb',TRUE),
			'mDisTar' => $this->input->post('disConnectionsFeb',TRUE),
			 ],

			 ['proID' => $this->input->post('productID',TRUE),
			'year' => $this->input->post('abpYear',TRUE),
			'month' => '3',
			'mRevTar' => $this->input->post('productRevenueMar',TRUE),
			'mSalesTar' => $this->input->post('newConnectionsMar',TRUE),
			'mDisTar' => $this->input->post('disConnectionsMar',TRUE),
			 ],

			 ['proID' => $this->input->post('productID',TRUE),
			'year' => $this->input->post('abpYear',TRUE),
			'month' => '4',
			'mRevTar' => $this->input->post('productRevenueApr',TRUE),
			'mSalesTar' => $this->input->post('newConnectionsApr',TRUE),
			'mDisTar' => $this->input->post('disConnectionsApr',TRUE),
			 ],

			 ['proID' => $this->input->post('productID',TRUE),
			'year' => $this->input->post('abpYear',TRUE),
			'month' => '5',
			'mRevTar' => $this->input->post('productRevenueMay',TRUE),
			'mSalesTar' => $this->input->post('newConnectionsMay',TRUE),
			'mDisTar' => $this->input->post('disConnectionsMay',TRUE),
			 ],

			 ['proID' => $this->input->post('productID',TRUE),
			'year' => $this->input->post('abpYear',TRUE),
			'month' => '6',
			'mRevTar' => $this->input->post('productRevenueJun',TRUE),
			'mSalesTar' => $this->input->post('newConnectionsJun',TRUE),
			'mDisTar' => $this->input->post('disConnectionsJun',TRUE),
			 ],

			 ['proID' => $this->input->post('productID',TRUE),
			'year' => $this->input->post('abpYear',TRUE),
			'month' => '7',
			'mRevTar' => $this->input->post('productRevenueJul',TRUE),
			'mSalesTar' => $this->input->post('newConnectionsJul',TRUE),
			'mDisTar' => $this->input->post('disConnectionsJul',TRUE),
			 ],

			 ['proID' => $this->input->post('productID',TRUE),
			'year' => $this->input->post('abpYear',TRUE),
			'month' => '8',
			'mRevTar' => $this->input->post('productRevenueAug',TRUE),
			'mSalesTar' => $this->input->post('newConnectionsAug',TRUE),
			'mDisTar' => $this->input->post('disConnectionsAug',TRUE),
			 ],

			 ['proID' => $this->input->post('productID',TRUE),
			'year' => $this->input->post('abpYear',TRUE),
			'month' => '9',
			'mRevTar' => $this->input->post('productRevenueSep',TRUE),
			'mSalesTar' => $this->input->post('newConnectionsSep',TRUE),
			'mDisTar' => $this->input->post('disConnectionsSep',TRUE),
			 ],

			 ['proID' => $this->input->post('productID',TRUE),
			'year' => $this->input->post('abpYear',TRUE),
			'month' => '10',
			'mRevTar' => $this->input->post('productRevenueOct',TRUE),
			'mSalesTar' => $this->input->post('newConnectionsOct',TRUE),
			'mDisTar' => $this->input->post('disConnectionsOct',TRUE),
			 ],

			 ['proID' => $this->input->post('productID',TRUE),
			'year' => $this->input->post('abpYear',TRUE),
			'month' => '11',
			'mRevTar' => $this->input->post('productRevenueNov',TRUE),
			'mSalesTar' => $this->input->post('newConnectionsNov',TRUE),
			'mDisTar' => $this->input->post('disConnectionsNov',TRUE),
			 ],

			 ['proID' => $this->input->post('productID',TRUE),
			'year' => $this->input->post('abpYear',TRUE),
			'month' => '12',
			'mRevTar' => $this->input->post('productRevenueDec',TRUE),
			'mSalesTar' => $this->input->post('newConnectionsDec',TRUE),
			'mDisTar' => $this->input->post('disConnectionsDec',TRUE),
			 ]

		];

		return $this->db->insert_batch('producttargets',$abpTarget);
	}


	public function loadTargetData(){

		//This will check the availability of data in database
		//This is to avoid the overwrite without knowledge of the user 
        
		$year = date('Y');
		$this->db->select('*');
		$this->db->from('producttargets');
		$this->db->where('year>=',$year);
		return $this->db->get();
		}


}

