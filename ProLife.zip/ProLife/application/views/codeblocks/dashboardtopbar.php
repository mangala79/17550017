 <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>

                    <!-- Topbar product & year selection -->
                   
                    
                    <div class="row">
                        <ul>
                            <li class="nav-item">
                                <div class="row">
                                    <div class="col-3">
                                        <label for="year" class="fas fa-fw">Year</label>
                                    </div>
                                    <div class="col-9">
                                        <select name="year" id="year" class="form-control">
                                            <option value="">select year</option>
                                              <?php
                                              foreach($year_list->result_array() as $row)
                                                  {
                                                    echo '<option value="'.$row["year"].'">'.$row["year"].'</option>';
                                                  }
                                              ?>
                                        </select>
                                    </div>                                    
                                </div>                             
                            </li>
                        </ul>
                    
                        <ul>
                            <li class="nav-item">
                                <div class="row">
                                    <div class="col-3">
                                        <label for="product" class="fas fa-fw">Product</label>
                                    </div>
                                    <div class="col-9">
                                        <select name="product" id="product" class="form-control">
                                            <option value="">select product ID</option>
                                              <?php
                                              foreach($product_list->result_array() as $row)
                                                  {
                                                    echo '<option value="'.$row["proID"].'">'.$row["proName"].'</option>';
                                                  }
                                              ?>
                                        </select>
                                    </div>                                 
                                </div>                           
                            </li>
                        </ul> 
                        <!--
                        <ul>
                            <li class="nav-item">
                                <div class="row">
                                    <div class="col-3">
                                        <label for="product" class="fas fa-fw">Pro. Manager</label>
                                    </div>
                                    <div class="col-9">
                                        <select name="manager" id="manager" class="form-control">
                                            <option value="">select product Manager</option>
                                              <?php
                                              foreach($manager_list->result_array() as $row)
                                                  {
                                                    echo '<option value="'.$row["userID"].'">'.$row["fName"].'</option>';
                                                  }
                                              ?>
                                        </select>
                                    </div>                                 
                                </div>                           
                            </li>
                        </ul> -->                      
                    </div>

                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">


                        <!-- Nav Item - Alerts -->
                        <li class="nav-item dropdown no-arrow mx-1">
                            <a class="nav-link dropdown-toggle" href="#" id="alertsDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-bell fa-fw"></i>
                                <!-- Counter - Alerts -->
                                <span class="badge badge-danger badge-counter">3</span>
                            </a>
                            <!-- Dropdown - Alerts -->
                            <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="alertsDropdown" id="DSS_Message">
                                <h6 class="dropdown-header" id="alert_header">
                                    Alerts Center
                                </h6>
                                <a class="dropdown-item d-flex align-items-center" href="#">
                                    <div class="mr-3">
                                        <div class="icon-circle bg-primary">
                                            <i class="fas fa-thumbs-up text-white"></i>
                                        </div>
                                    </div>
                                    <div>
                                        <div class="small text-gray-500">Plus Points</div>
                                        <div id="M1"></div>
                                        <div id="M2"></div>
                                        <div id="M3"></div>
                                        <div id="M4"></div>
                                        <div id="M11"></div>
                                        <div id="M12"></div>
                                        <div id="M13"></div>
                                        <div id="M14"></div>
                                        <div id="M15"></div>
                                        <div id="M20"></div>
                                        <div id="M21"></div>
                                        <div id="M22"></div>
                                    </div>
                                </a>
                                <a class="dropdown-item d-flex align-items-center" href="#">
                                    <div class="mr-3">
                                        <div class="icon-circle bg-success">
                                            <i class="fas fa-info-circle text-white"></i>
                                        </div>
                                    </div>
                                    <div>
                                        <div class="small text-gray-500">Product Hints</div>
                                        <div id="M9"></div>
                                        <div id="M10"></div>
                                        <div id="M11"></div>
                                        <div id="M24"></div>
                                    </div>
                                </a>
                                <a class="dropdown-item d-flex align-items-center" href="#">
                                    <div class="mr-3">
                                        <div class="icon-circle bg-warning">
                                            <i class="fas fa-exclamation-triangle text-white"></i>
                                        </div>
                                    </div>
                                    <div>
                                        <div class="small text-gray-500">Warnings</div>
                                        <div id="M5"></div>
                                        <div id="M6"></div>
                                        <div id="M7"></div>
                                        <div id="M8"></div>
                                        <div id="M16"></div>
                                        <div id="M17"></div>
                                        <div id="M18"></div>
                                        <div id="M19"></div>
                                        <div id="M23"></div>
                                    </div>
                                </a>
                                <a class="dropdown-item text-center small text-gray-500" href="#">Show All Alerts</a>
                            </div>
                        </li>

                        <!-- Nav Item - Messages -->
                        <li class="nav-item dropdown no-arrow mx-1">
                            <a class="nav-link dropdown-toggle" href="#" id="messagesDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-list fa-fw"></i>
                                <!-- Counter - Messages -->
                                <span class="badge badge-danger badge-counter">2</span>
                            </a>
                            <!-- Dropdown - Messages -->
                            <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="messagesDropdown">
                                <h6 class="dropdown-header">
                                    Management reports
                                </h6>
                                <a class="dropdown-item d-flex align-items-center" onclick="generatepdf();" id='save-pdf'>
                                    <div class="dropdown-list-image mr-3">
                                        <img class="rounded-circle" src="assets/img/undraw_profile_1.svg"
                                            alt="...">
                                        <div class="status-indicator bg-success"></div>
                                    </div>
                                    <div class="font-weight-bold">
                                        <div class="text-truncate"> Product analysis report in PDF format</div>
                                        <div class="small text-gray-500">With market interpretations</div>
                                    </div>
                                </a>
                                <a class="dropdown-item d-flex align-items-center" href="<?php echo base_url('index.php/DashboardCon/exportCSV');?>">
                                    <div class="dropdown-list-image mr-3">
                                        <img class="rounded-circle" src="assets/img/undraw_profile_2.svg"
                                            alt="...">
                                        <div class="status-indicator"></div>
                                    </div>
                                    <div>
                                        <div class="text-truncate" >Report based data in CSV format</div>
                                        <div class="small text-gray-500">Directly extract from database </div>
                                    </div>
                                </a>
                                <a class="dropdown-item text-center small text-gray-500" href="#">Read More Messages</a>
                            </div>
                        </li>

                        <div class="topbar-divider d-none d-sm-block"></div>

                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a id="userDropdown" class="nav-link dropdown-toggle" href="#" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?php echo $this->session->userdata('fName') ?></span>
                                <img class="img-profile rounded-circle"
                                    src="<?php echo base_url ('assets/img/undraw_profile.svg'); ?>">
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="userDropdown">
                                <!--
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Profile
                                </a>
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Settings
                                </a>
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Activity Log
                                </a>-->
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Logout
                                </a>
                            </div>
                        </li>

                    </ul>

                </nav>