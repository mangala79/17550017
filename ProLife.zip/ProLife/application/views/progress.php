<?php if($this->session->userdata('admin')=='admin'){
            include 'codeblocks/adminheader.php';
        }
        else{
            include 'codeblocks/header.php';
        }
?>

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php include 'codeblocks/topbar.php'?> 
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Progress update</h1>
                    </div>

                    <!-- Content Row -->

                    <div class="row">

                        <!-- Form area -->
                        <div class="col-xl-8 col-lg-7">
                            <div class="card shadow mb-4">
                                <!-- Card Header - Dropdown -->
                                <div
                                    class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-primary">Update monthly progress of the products here</h6>
                                </div>
                                <!-- Card Body -->
                                <div class="card-body">
                                	<div>

                                        <?php
                                            if ($this->session->flashdata('msg_success_progressdata'))
                                            {
                                              ?>
                                              <div class="alert-success" role="alert">
                                              <h4 class="alert-heading">Well done!</h4>
                                              <hr>
                                              <?php echo "<a>",$this->session->flashdata('msg_success_progressdata'),"</a>"; ?>
                                              </div>
                                              <?php

                                            }


                                            if ($this->session->flashdata('msg_duplicate_progressdata'))
                                            {
                                              ?>
                                              <div class="alert-danger" role="alert">
                                              <h4 class="alert-heading">Oops!</h4>
                                              <hr> 
                                              <?php echo "<a>",$this->session->flashdata('msg_duplicate_progressdata'),"</a>"; ?>
                                              </div>
                                              <?php                                             

                                            }

                                             if ($this->session->flashdata('msg_absent_early_progressdata'))
                                            {
                                              ?>
                                              <div class="alert-danger" role="alert">
                                              <h4 class="alert-heading">Oops!</h4>
                                              <hr> 
                                              <?php echo "<a>",$this->session->flashdata('msg_absent_early_progressdata'),"</a>"; ?>
                                              </div>
                                              <?php                                             

                                            }

                                          if ($this->session->flashdata('msg_success_targetdata'))
                                            {
                                              ?>
                                              <div class="alert-success" role="alert">
                                              <h4 class="alert-heading">Well done!</h4>
                                              <hr> 
                                              <?php echo "<a>",$this->session->flashdata('msg_success_targetdata'),"</a>"; ?>
                                              </div>
                                              <?php                                             

                                            }   
                                                
                                          if (validation_errors())
                                            {
                                                ?>
                                                <div class="alert-danger" role="alert">
                                                <h4 class="alert-heading">Oops!</h4>
                                                <hr>
                                                <?php echo validation_errors(); ?>
                                                </div>
                                                <?php
                                            }
                                        ?>
                                    </div>
                                    <?php echo form_open('ProgressCon/progressdata');?>
                      
				                        <div class="form-group">
				                          
					                        <label for="updateYear">Year</label>
				                            <select id="updateYear" name="updateYear" class="form-control">
				                              <option value="2017">2017</option>
				                              <option value="2018">2018</option>
				                              <option value="2019">2019</option>
				                              <option value="2020">2020</option>
				                              <option value="2021">2021</option>
				                              <option value="2022">2022</option>
				                              <option value="2023">2023</option>
				                              <option value="2024">2024</option>
				                            </select> 
				                          

				                          	<label for="updateMonth">Month</label>
					                          	<select id="updateMonth" name="updateMonth" class="form-control">
					                              	<option value="01">JANUARY</option>
					                              	<option value="02">FEBRUARY</option>
					                              	<option value="03">MARCH</option>
						                            <option value="04">APRIL</option>
						                            <option value="05">MAY</option>
						                            <option value="06">JUNE</option>
						                            <option value="07">JULY</option>
						                            <option value="08">AUGUST</option>
						                            <option value="09">SEPTEMBER</option>
						                            <option value="10">OCTOBER</option>
						                            <option value="11">NOVEMBER</option>
						                            <option value="12">DECEMBER </option>
					                            </select>

				                            <label for="productID">Product Name</label>
					                        
                                            <div class="form-row">
                                                <div class="form-group">
                                                    <select name="productID" id="productID" class="form-control">
                                                        <option value="">select product name</option>
                                                          <?php
                                                          foreach($product_list->result_array() as $row)
                                                              {
                                                                echo '<option value="'.$row["proID"].'">'.$row["proName"].'</option>';
                                                              }
                                                          ?>
                                                    </select>
                                                </div>                                            
                                            </div>


				                            <label for="productRevenue">Revenue</label>
					                            <input type="number" name="productRevenue" class="form-control" id="productRevenue" placeholder="Revenue according to the BSS reports in millions">
				                          

				                          	<label for="newConnections">Nnumber of New Connections</label>
				                          		<input type="number" name="newConnections" class="form-control" id="newConnections" placeholder="Nnumber of new connections according to the BSS reports">

				                          	<label for="totalDisconnections">Number of Disconnections</label>
				                          		<input type="number" name="totalDisconnections" class="form-control" id="totalDisconnections" placeholder="Nnumber of new connections according to the BSS reports">
				                          
				                          	<label for="customerBase">Customer Base</label>
				                          		<input type="number" name="customerBase" class="form-control" id="customerBase" placeholder="Customer base at the end of the month">
				                      
				                        </div>

				                        <br>

				                        <div class="raw">
				                          <button type="submit" class="btn btn-primary">submit</button> 
				                        </div>  

				                    <?php echo form_close(); ?> 
                                </div>
                            </div>
                        </div>

                        <!-- Instruction area  -->
                        <div class="col-xl-4 col-lg-5">
                            <div class="card shadow mb-4">
                                <!-- Card Header - Dropdown -->
                                <div
                                    class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-primary">Instructions</h6>
                                </div>
                                <!-- Card Body -->
                                <div class="card-body">
                                    <P class="lead text-justify" style="font-size:80%">
                                        System will not allow to update the immediate past month data, if you have missed the update of any previous month. You must edit previous month first.
                                    </P>
                                    <span style="font-size:80%">Check the available data </span>
                                    <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#Progressdata">here</button>
                                    <br><br> 
                                    <span style="font-size:80%">If you want to update the existing data click </span>
                                    <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#updateAvailableData">here</button>
                                </div>
                            </div>
                        </div>
                    </div>

                    
                </div>
                <!-- /.container-fluid -->
  
                <!-- Modal for check the available progress data-->
                <div class="modal fade" id="Progressdata" role="dialog">
                    <div class="modal-dialog">
                    
                      <!-- Modal content-->
                      <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title font-weight-bold text-primary">Available progress data</h5>
                            <button type="button" class="close" data-dismiss="modal">&times;</button>  
                        </div>
                        <div class="modal-body">
                            <table border="0">  
                                <tbody>  
                                    <tr>  
                                        <td>ProID</td>
                                        <td>year</td>
                                        <td>month</td>  
                                        <td>proRevenue</td> 
                                        <td>cxBase</td> 
                                        <td>mSales</td>  
                                        <td>mDis</td> 
                                    </tr>  
                                <?php  
                                foreach ($Progressdata->result() as $row)  
                                {  
                                    ?><tr>
                                    <td><?php echo $row->ProID;?></td> 
                                    <td><?php echo $row->year;?></td>  
                                    <td><?php echo $row->month;?></td>  
                                    <td><?php echo $row->proRevenue;?></td>
                                    <td><?php echo $row->cxBase;?></td>
                                    <td><?php echo $row->mSales;?></td>
                                    <td><?php echo $row->mDis;?></td>  
                                    </tr>  
                                <?php }  
                                ?>  
                                </tbody>  
                            </table>   
                        </div>

                        <div class="modal-footer">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        </div>
                      </div>
                      
                    </div>
                </div>

                <!-- Modal to update existing progress data-->
                <div class="modal fade" id="updateAvailableData" role="dialog">
                    <div class="modal-dialog">
                    
                      <!-- Modal content-->
                      <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title font-weight-bold text-primary">Update available progress data</h5>
                            <button type="button" class="close" data-dismiss="modal">&times;</button>  
                        </div>
                        <div class="modal-body">

                            <?php echo form_open('ProgressCon/updateAvailableData');?>
                      
                                        <div class="form-group">
                                          
                                            <label for="updateYear">Year</label>
                                            <select id="updateYear" name="updateYear" class="form-control">
                                              <option value="2017">2017</option>
                                              <option value="2018">2018</option>
                                              <option value="2019">2019</option>
                                              <option value="2020">2020</option>
                                              <option value="2021">2021</option>
                                              <option value="2022">2022</option>
                                              <option value="2023">2023</option>
                                              <option value="2024">2024</option>
                                            </select> 
                                          

                                            <label for="updateMonth">Month</label>
                                                <select id="updateMonth" name="updateMonth" class="form-control">
                                                    <option value="01">JANUARY</option>
                                                    <option value="02">FEBRUARY</option>
                                                    <option value="03">MARCH</option>
                                                    <option value="04">APRIL</option>
                                                    <option value="05">MAY</option>
                                                    <option value="06">JUNE</option>
                                                    <option value="07">JULY</option>
                                                    <option value="08">AUGUST</option>
                                                    <option value="09">SEPTEMBER</option>
                                                    <option value="10">OCTOBER</option>
                                                    <option value="11">NOVEMBER</option>
                                                    <option value="12">DECEMBER </option>
                                                </select>

                                            <label for="productID">Product Name</label>
                                            
                                            <div class="form-row">
                                                <div class="form-group">
                                                    <select name="productID" id="productID" class="form-control">
                                                        <option value="">select product name</option>
                                                          <?php
                                                          foreach($product_list->result_array() as $row)
                                                              {
                                                                echo '<option value="'.$row["proID"].'">'.$row["proName"].'</option>';
                                                              }
                                                          ?>
                                                    </select>
                                                </div>                                            
                                            </div>


                                            <label for="productRevenue">Revenue</label>
                                                <input type="number" name="productRevenue" class="form-control" id="productRevenue" placeholder="Revenue according to the BSS reports in millions">
                                          

                                            <label for="newConnections">Nnumber of New Connections</label>
                                                <input type="number" name="newConnections" class="form-control" id="newConnections" placeholder="Nnumber of new connections according to the BSS reports">

                                            <label for="totalDisconnections">Number of Disconnections</label>
                                                <input type="number" name="totalDisconnections" class="form-control" id="totalDisconnections" placeholder="Nnumber of new connections according to the BSS reports">
                                          
                                            <label for="customerBase">Customer Base</label>
                                                <input type="number" name="customerBase" class="form-control" id="customerBase" placeholder="Customer base at the end of the month">
                                      
                                        </div>

                                        <br>

                                        <div class="raw">
                                          <button type="submit" class="btn btn-primary">Update</button> 
                                        </div>  

                                    <?php echo form_close(); ?>
                               
                        </div>

                        <div class="modal-footer">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        </div>
                      </div>
                      
                    </div>
                </div>
                


            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; MIT-UCSC 2021</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

<?php include 'codeblocks/footer.php'?>      