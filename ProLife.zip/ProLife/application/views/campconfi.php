<?php if($this->session->userdata('admin')=='admin'){
            include 'codeblocks/adminheader.php';
        }
        else{
            include 'codeblocks/header.php';
        }
?>

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php include 'codeblocks/topbar.php'?> 
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Campaign configuration</h1>
                    </div>

                    <!-- Content Row -->

                    <div class="row">

                        <!-- Form Area -->
                        <div class="col-xl-8 col-lg-7">
                            <div class="card shadow mb-4">
                                <!-- Card Header - Dropdown -->
                                <div
                                    class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-primary">Enter your campaign details here</h6>
                                </div>
                                <!-- Card Body -->
                                <div class="card-body">

                                    <div>

                                        <?php
                                          if ($this->session->flashdata('msg_success_campdata'))
                                            {
                                              ?>
                                              <div class="alert-success" role="alert">
                                              <h4 class="alert-heading">Well done!</h4>
                                              <hr>
                                              <?php echo "<a>",$this->session->flashdata('msg_success_campdata'),"</a>"; ?>
                                              </div>
                                              <?php

                                            }  
                                                
                                          if (validation_errors())
                                            {
                                                ?>
                                                <div class="alert-danger" role="alert">
                                                <h4 class="alert-heading">Oops!</h4>
                                                <hr>
                                                <?php echo validation_errors(); ?>
                                                </div>
                                                <?php
                                            }
                                        ?>
                                        

                                    </div>

                                    

                                    <!-- begining of the form-->
                                    
                                    <?php echo form_open('CampCon/campdata'); ?> 
                      
                                        <div class="form-row">
                                          <div class="form-group">
                                          
                                            <label for="productName">Product name</label>
                                            
                                            <div class="form-row">
                                                <div class="form-group">
                                                    <select name="productName" id="productName" class="form-control">
                                                        <option value="">select product name</option>
                                                          <?php
                                                          foreach($product_list->result_array() as $row)
                                                              {
                                                                echo '<option value="'.$row["proID"].'">'.$row["proName"].'</option>';
                                                              }
                                                          ?>
                                                    </select>
                                                </div>                                            
                                            </div>

                                            <small id="productName" class="form-text text-muted">Please enter the product name correctly as configured in other system  </small>

                                            <label for="campaignName ">Campaign Name </label>
                                            <input type="text" name="campaignName" class="form-control" id="campaignName" placeholder="Enter new campaign name">

                                            <label for="campInitiation">Campaign Initiation Fee</label>
                                            <input type="number" name="campInitiation" class="form-control" id="campInitiation" placeholder="Campaign Initiation fee">

                                            <label for="campStartDate ">Campaign Start Date</label>
                                            <input type="date" name="campStartDate" class="form-control" id="campStartDate">

                                            <label for="campEndtDate ">Campaign End Date</label>
                                            <input type="date" name="campEndtDate" class="form-control" id="campEndtDate">

                                            <label for="campCost">Budgeted cost for campaign </label>
                                            <input type="number" name="campCost" class="form-control" id="campCost" placeholder="Budgeted cost in millions">
                                        

                                            
                                          </div>
                                          
                                        </div>
                                        

                                        <div class="raw">
                                          <button type="submit" class="btn btn-primary" id="submit">submit</button> 
                                        </div>  

                                    <?php echo form_close(); ?>
                                    <!-- end of the form-->
                                </div>
                            </div>
                        </div>

                        <!-- Instruction area  -->
                        <div class="col-xl-4 col-lg-5">
                            <div class="card shadow mb-4">
                                <!-- Card Header - Dropdown -->
                                <div
                                    class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-primary">Instructions</h6>
                                </div>
                                <!-- Card Body -->
                                <div class="card-body">
                                    <P class="lead text-justify" style="font-size:80%">
                                        Only campaigns planed for future can be added in this window
                                    </P>
                                    <P class="lead text-justify" style="font-size:80%">
                                        Do not enter regional level campaigns in this window. System does not have capability to analysis reginal level effect
                                    </P>
                                    <P class="lead text-justify" style="font-size:80%">
                                        Effectiveness and profitability of the campaign can be checked on system generated product report after end of the campaign 
                                    </P>
                                </div>
                            </div>
                        </div>
                    </div>

                    
                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; MIT-UCSC 2021</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

<?php include 'codeblocks/footer.php'?>
