<?php if($this->session->userdata('admin')=='admin'){
            include 'codeblocks/adminheader.php';
        }
        else{
            include 'codeblocks/header.php';
        }
?>

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php include 'codeblocks/topbar.php'?>                
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Product Configuration</h1>
                    </div>

                    <!-- Content Row -->

                    <div class="row">

                        <!-- Form Area -->
                        <div class="col-xl-8 col-lg-7">
                            <div class="card shadow mb-4">
                                <!-- Card Header - Dropdown -->
                                <div
                                    class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-primary">Product details</h6>
                                </div>
                                <!-- Card Body -->
                                <div class="card-body">

                                  <div>

                                    <?php
                                      if ($this->session->flashdata('msg_success_prodata'))
                                        {
                                          ?>
                                          <div class="alert-success" role="alert">
                                          <h4 class="alert-heading">Well done!</h4>
                                          <hr>
                                          <?php echo "<a>",$this->session->flashdata('msg_success_prodata'),"</a>"; ?>
                                          </div>
                                          <?php

                                        }  
                                            
                                      if (validation_errors())
                                        {
                                            ?>
                                            <div class="alert-danger" role="alert">
                                            <h4 class="alert-heading">Oops!</h4>
                                            <hr>
                                            <?php echo validation_errors(); ?>
                                            </div>
                                            <?php
                                        }
                                    ?>
                                        

                                  </div>

                                    <!-- begining of the form-->
                                    <?php echo form_open('ProconfiCon/prodata'); ?> 
                      
                                        <div class="form-row">
                                          <div class="form-group">
                                          
                                            <label for="productName">Product name</label>
                                            <input type="text" name="productName" class="form-control" id="productName" placeholder="Enter new product name">
                                            <small id="productName" class="form-text text-muted">Please enter the product name correctly as configured in other system  </small>

                                            <label for="productdescription">Product Description</label>
                                            <input type="text" name="productdescription" class="form-control" id="productdescription" placeholder="Enter new product description ">
                                            <small id="productName" class="form-text text-muted">Please enter the product product description</small>

                                            <label for="productManagerName">Product managers' name</label>
                                            
                                            <div class="form-row">
                                                <div class="form-group">
                                                    <select name="productManagerName" id="productManagerName" class="form-control">
                                                        <option value="">select product manager</option>
                                                          <?php
                                                          foreach($manager_list->result_array() as $row)
                                                              {
                                                                echo '<option value="'.$row["userID"].'">'.$row["fName"].'</option>';
                                                              }
                                                          ?>
                                                    </select>
                                                </div>                                            
                                            </div>

                                            <small id="productName" class="form-text text-muted">Please Select the Product Managers' Name </small>

                                            <label for="launchedDate ">Launched date</label>
                                            <input type="date" name="launchedDate" class="form-control" id="launchedDate">
                                        

                                            <label for="Strategy">Strategy</label>
                                              <select class="form-control" id="Strategy" name="Strategy">
                                                <option selected>market penetration</option>
                                                <option>market development</option>
                                              </select>  
                                        

                                            <label for="noofCompetitors">No of Competitors</label>
                                            <input type="number" name="noofCompetitors" class="form-control" id="noofCompetitors" placeholder="Enter the no of Competitors">

                                            <label for="proInitiation">Product Initiation fee</label>
                                            <input type="number" name="proInitiation" class="form-control" id="proInitiation" placeholder="Product Initiation fee">

                                            <label for="mRental">Monthly rental</label>
                                            <input type="number" name="mRental" class="form-control" id="mRental" placeholder="Monthly rental">

                                          </div>
                                          
                                        </div>
                                        

                                        <div class="form-row">
                                          <div class="form-group" >
                                            <label for="Tariff">Tariff
                                            </label>
                                          </div>
                                        </div>

                                        <div class="form-row">
                                          
                                          <div class="form-group col-md-2" >
                                            <label for="blank">
                                            </label>
                                          </div>

                                          <div class="form-group col-md-2" >
                                            <label for="onNet">
                                              On net
                                            </label>
                                          </div>

                                          <div class="form-group col-md-2" >
                                            <label for="offNet">
                                              Off net
                                            </label>
                                          </div>
                                        </div>

                                        <div class="form-row">
                                          
                                          <div class="form-group col-md-2" >
                                            <label for="Peek">
                                              Peek
                                            </label>
                                          </div>

                                          <div class="form-group col-md-2" >
                                            <input type="text" name="peekOnNet" class="form-control" id="peekOnNet" placeholder="Peek On Net">
                                          </div>

                                          <div class="form-group col-md-2" >
                                            <input type="text" name="peekOffNet" class="form-control" id="peekOffNet" placeholder="Peek Off Net">
                                          </div>
                                      
                                        </div>

                                        <div class="form-row">
                                          
                                          <div class="form-group col-md-2" >
                                            <label for="offPeek">
                                              Off Peek
                                            </label>
                                          </div>

                                          <div class="form-group col-md-2" >
                                            <input type="text" name="offPeekOnNet" class="form-control" id="offPeekOnNet" placeholder="Off Peek On Net">
                                          </div>

                                          <div class="form-group col-md-2" >
                                            <input type="text" name="offPeekOffNet" class="form-control" id="offPeekOffNet" placeholder="Off Peek Off Net">
                                          </div>
                                                    
                                        </div>


                                        <div class="raw">
                                          <button type="submit" class="btn btn-primary" id="submit">submit</button> 
                                        </div>  

                                    <?php echo form_close(); ?>
                                    <!-- end of the form-->
                                </div>
                            </div>
                        </div>

                        <!-- Instruction area  -->
                        <div class="col-xl-4 col-lg-5">
                            <div class="card shadow mb-4">
                                <!-- Card Header - Dropdown -->
                                <div
                                    class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-primary">Instructions</h6>
                                </div>
                                <!-- Card Body -->
                                <div class="card-body">
                                    <span>Product can be configured which are planned to launch within next 90 days or product which have already launched. </span>
                                </div>
                            </div>
                        </div>
                    </div>

                    
                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; MIT-UCSC 2021</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

<?php include 'codeblocks/footer.php'?>    