<?php if($this->session->userdata('admin')=='admin'){
            include 'codeblocks/adminheader.php';
        }
        else{
            include 'codeblocks/header.php';
        }
?>

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php include 'codeblocks/topbar.php'?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Cost onfiguration</h1>
                    </div>

                    <!-- Content Row -->

                    <div class="row">

                        <!-- Area Chart -->
                        <div class="col-xl-8 col-lg-7">
                            <div class="card shadow mb-4">
                                <!-- Card Header - Dropdown -->
                                <div
                                    class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-primary">Update product cost details here</h6>
                                </div>
                                <!-- Card Body -->
                                <div class="card-body">


                                	<div>

                                        <?php
                                            if ($this->session->flashdata('msg_success_costdata'))
                                            {
                                              ?>
                                              <div class="alert-success" role="alert">
                                              <h4 class="alert-heading">Well done!</h4>
                                              <hr>
                                              <?php echo "<a>",$this->session->flashdata('msg_success_costdata'),"</a>"; ?>
                                              </div>
                                              <?php

                                            }

                                            if ($this->session->flashdata('msg_duplicate_costdata'))
                                            {
                                              ?>
                                              <div class="alert-danger" role="alert">
                                              <h4 class="alert-heading">Oops!</h4>
                                              <hr> 
                                              <?php echo "<a>",$this->session->flashdata('msg_duplicate_costdata'),"</a>"; ?>
                                              </div>
                                              <?php                                             

                                            }  
                                                
                                          if (validation_errors())
                                            {
                                                ?>
                                                <div class="alert-danger" role="alert">
                                                <h4 class="alert-heading">Oops!</h4>
                                                <hr>
                                                <?php echo validation_errors(); ?>
                                                </div>
                                                <?php
                                            }
                                        ?>
                                        

                                    </div>

                                    
                                    <?php echo form_open('CostCon/costdata'); ?>
                                    	<div class="form-group">
				                          
				                           <label for="productID">Product Name</label>
					                       
                                           <div class="form-row">
                                                <div class="form-group">
                                                    <select name="productID" id="productID" class="form-control">
                                                        <option value="">select product name</option>
                                                          <?php
                                                          foreach($product_list->result_array() as $row)
                                                              {
                                                                echo '<option value="'.$row["proID"].'">'.$row["proName"].'</option>';
                                                              }
                                                          ?>
                                                    </select>
                                                </div>                                            
                                            </div>

				                          <label for="capexInvestment  ">CAPEX</label>
				                          <input type="number" name="capexInvestment" class="form-control" id="capexInvestment">
				                          <small id="capexInvestment" class="form-text text-muted">Please enter the Initial investment for the product in millions (Rs.) </small>
				                          <div class="alert-danger" role="alert">
				                            <div id="em2"></div>
				                          </div>

				                          <br>
				                          <h5>OPEX</h5>
				                          <hr class="my-4">

				                          <label for="networkCost   ">Network Cost</label>
				                          <input type="number" name="networkCost" class="form-control" id="networkCost" placeholder="Per month in millions">
				                          <div class="alert-danger" role="alert">
				                            <div id="em3"></div>
				                          </div>

				                          <label for="cpeCost">CPE Cost</label>
				                          <input type="number" name="cpeCost" class="form-control" id="cpeCost" placeholder="Per month in millions">
				                          <div class="alert-danger" role="alert">
				                            <div id="em4"></div>
				                          </div>
				                          
				                          <label for="atlCost">ATL Cost</label>
				                          <input type="number" name="atlCost" class="form-control" id="atlCost" placeholder="Per month in millions">
				                          <div class="alert-danger" role="alert">
				                            <div id="em5"></div>
				                          </div>

				                          <label for="btlCost">BTL Cost</label>
				                          <input type="number" name="btlCost" class="form-control" id="btlCost" placeholder="Per month in millions">
				                          <div class="alert-danger" role="alert">
				                            <div id="em6"></div>
				                          </div>

				                          <label for="otherCost">Other Cost</label>
				                          <input type="number" name="otherCost" class="form-control" id="otherCost" placeholder="Per month in millions">
				                          <div class="alert-danger" role="alert">
				                            <div id="em7"></div>
				                          </div>
				                      
				                        </div>

				                        <div class="raw">
				                          <button type="submit" class="btn btn-primary" id="costsubmit">submit</button> 
				                        </div>  

				                      <?php echo form_close(); ?> 
				                      
                                </div>
                            </div>
                        </div>

                        <!-- Pie Chart -->
                        <div class="col-xl-4 col-lg-5">
                            <div class="card shadow mb-4">
                                <!-- Card Header - Dropdown -->
                                <div
                                    class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-primary">Instructions</h6>
                                </div>
                                <!-- Card Body -->
                                <div class="card-body">
                                    <div class="card-body">
                                    <P class="lead text-justify" style="font-size:80%">
                                        If the system is not allowing to enter the cost data, please check the data availability . 
                                    </P>
                                    <span style="font-size:80%">Check the available data </span>
                                    <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#costdata">Here</button>

                                    <P class="lead text-justify" style="font-size:80%">
                                        
                                    </P>
                                    <span style="font-size:80%">If you want to update the existing cost data please click  </span>
                                    <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#updateAvailableCostData">here</button> 
                                </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    
                </div>
                <!-- /.container-fluid -->

                 <!-- Modal  to check the available cost data-->
                <div class="modal fade" id="costdata" role="dialog">
                    <div class="modal-dialog">
                    
                      <!-- Modal content-->
                      <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title font-weight-bold text-primary">Available cost data</h5>
                            <button type="button" class="close" data-dismiss="modal">&times;</button>  
                        </div>
                        <div class="modal-body">
                            <table border="0">  
                                <tbody>  
                                    <tr>  
                                        <td>ProID</td>
                                        <td>CAPEX</td>  
                                        <td>nwCost</td> 
                                        <td>cpeCost</td> 
                                        <td>btlCost</td>  
                                        <td>atlCost</td> 
                                        <td>otherCost</td> 
                                    </tr>  
                                <?php  
                                foreach ($costdata->result() as $row)  
                                {  
                                    ?><tr>
                                    <td><?php echo $row->proID;?></td>  
                                    <td><?php echo $row->CAPEX;?></td>  
                                    <td><?php echo $row->nwCost;?></td>
                                    <td><?php echo $row->cpeCost;?></td>
                                    <td><?php echo $row->btlCost;?></td>
                                    <td><?php echo $row->atlCost;?></td> 
                                    <td><?php echo $row->otherCost;?></td> 
                                    </tr>  
                                <?php }  
                                ?>  
                                </tbody>  
                            </table>   
                        </div>

                        <div class="modal-footer">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        </div>
                      </div>
                      
                    </div>
                </div>

                <!-- Modal to update the available cost data-->
                <div class="modal fade" id="updateAvailableCostData" role="dialog">
                    <div class="modal-dialog">
                    
                      <!-- Modal content-->
                      <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title font-weight-bold text-primary">Update available cost data</h5>
                            <button type="button" class="close" data-dismiss="modal">&times;</button>  
                        </div>
                        <div class="modal-body">

                            <?php echo form_open('CostCon/updateCostData'); ?>
                                <div class="form-group">
                                  
                                   <label for="productID">Product Name</label>
                                   
                                   <div class="form-row">
                                        <div class="form-group">
                                            <select name="productID" id="productID" class="form-control">
                                                <option value="">select product name</option>
                                                  <?php
                                                  foreach($product_list->result_array() as $row)
                                                      {
                                                        echo '<option value="'.$row["proID"].'">'.$row["proName"].'</option>';
                                                      }
                                                  ?>
                                            </select>
                                        </div>                                            
                                    </div>

                                  <label for="capexInvestment  ">CAPEX</label>
                                  <input type="number" name="capexInvestment" class="form-control" id="capexInvestment">
                                  <small id="capexInvestment" class="form-text text-muted">Please enter the Initial investment for the product in millions (Rs.) </small>
                                  <div class="alert-danger" role="alert">
                                    <div id="em2"></div>
                                  </div>

                                  <br>
                                  <h5>OPEX</h5>
                                  <hr class="my-4">

                                  <label for="networkCost   ">Network Cost</label>
                                  <input type="number" name="networkCost" class="form-control" id="networkCost" placeholder="Per month in millions">
                                  <div class="alert-danger" role="alert">
                                    <div id="em3"></div>
                                  </div>

                                  <label for="cpeCost">CPE Cost</label>
                                  <input type="number" name="cpeCost" class="form-control" id="cpeCost" placeholder="Per month in millions">
                                  <div class="alert-danger" role="alert">
                                    <div id="em4"></div>
                                  </div>
                                  
                                  <label for="atlCost">ATL Cost</label>
                                  <input type="number" name="atlCost" class="form-control" id="atlCost" placeholder="Per month in millions">
                                  <div class="alert-danger" role="alert">
                                    <div id="em5"></div>
                                  </div>

                                  <label for="btlCost">BTL Cost</label>
                                  <input type="number" name="btlCost" class="form-control" id="btlCost" placeholder="Per month in millions">
                                  <div class="alert-danger" role="alert">
                                    <div id="em6"></div>
                                  </div>

                                  <label for="otherCost">Other Cost</label>
                                  <input type="number" name="otherCost" class="form-control" id="otherCost" placeholder="Per month in millions">
                                  <div class="alert-danger" role="alert">
                                    <div id="em7"></div>
                                  </div>
                              
                                </div>

                                <div class="raw">
                                  <button type="submit" class="btn btn-primary" id="costsubmit">Update</button> 
                                </div>  

                            <?php echo form_close(); ?> 
                               
                        </div>

                        <div class="modal-footer">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        </div>
                      </div>
                      
                    </div>
                </div>

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; MIT-UCSC 2021</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->


        

<?php include 'codeblocks/footer.php'?>   