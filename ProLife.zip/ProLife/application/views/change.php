<?php if($this->session->userdata('admin')=='admin'){
            include 'codeblocks/adminheader.php';
        }
        else{
            include 'codeblocks/header.php';
        }
?>

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                
                <?php include 'codeblocks/topbar.php'?>
                
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                    </div>

                    <!-- Content Row -->

                    <div class="row">

                        <div class="col-lg-5 d-none d-lg-block">
                            <img src="<?php echo base_url ('assets/img/telecom.png'); ?>" class="mx-auto d-block img-fluid" alt="" style="width: 800px; height: 400px;">
                        </div>
                        <div class="col-lg-7">
                            <div class="p-5">
                                <div class="text-center">
                                    <h1 class="h4 text-gray-900 mb-4">Change Password</h1>
                                    <?php if ($this->session->flashdata('msg_passwordchange_success')){
                                        echo "<h4>".$this->session->flashdata('msg_passwordchange_success')."</h4>";
                                    }?>
                                </div>
                                <?php echo validation_errors(); ?>
                                <?php echo form_open('Register/ResetPassword') ?>
                                    <div class="form-group row">
                                        <div class="col-sm-6 mb-3 mb-sm-0">
                                            <input type="password" class="form-control form-control-user" id="OldPassword" name="OldPassword" 
                                                placeholder="Existing password">
                                        </div>
                                        
                                    </div>
                                    
                                    <div class="form-group row">
                                        <div class="col-sm-6 mb-3 mb-sm-0">
                                            <input type="password" class="form-control form-control-user" name="newPassword" 
                                                id="newPassword" placeholder="New Password">
                                        </div>
                                        <div class="col-sm-6">
                                            <input type="password" class="form-control form-control-user" name="RepeatPassword" 
                                                id="RepeatPassword" placeholder="Repeat Password">
                                        </div>
                                    </div>
                                    
                                    <button class="btn btn-primary btn-user btn-block" type="submit">Reset</button>
                                <?php echo form_close(); ?>
                            </div>

                            <?php
                                if ($this->session->flashdata('msg_success_costdata'))
                                {
                                  ?>
                                  <div class="alert-success" role="alert">
                                  <h4 class="alert-heading">Well done!</h4>
                                  <hr>
                                  <?php echo "<a>",$this->session->flashdata('msg_passwordchange_success'),"</a>"; ?>
                                  </div>
                                  <?php

                                }
                            ?>
                        </div>
                    </div>

                    
                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; MIT-UCSC 2021</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

<?php include 'codeblocks/footer.php'?>    