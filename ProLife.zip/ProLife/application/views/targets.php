<?php if($this->session->userdata('admin')=='admin'){
            include 'codeblocks/adminheader.php';
        }
        else{
            include 'codeblocks/header.php';
        }
?>

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php include 'codeblocks/topbar.php'?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Annual target</h1>
                    </div>

                    <!-- Content Row -->

                    <div class="row">

                        <!-- Area Chart -->
                        <div class="col-xl-8 col-lg-7">
                            <div class="card shadow mb-4">
                                <!-- Card Header - Dropdown -->
                                <div
                                    class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-primary">Update the annual targets here</h6>
                                </div>
                                <!-- Card Body -->
                                <div class="card-body">

                                    <div>

                                        <?php
                                            if ($this->session->flashdata('msg_success_costdata'))
                                            {
                                              ?>
                                              <div class="alert-success" role="alert">
                                              <h4 class="alert-heading">Well done!</h4>
                                              <hr>
                                              <?php echo "<a>",$this->session->flashdata('msg_success_costdata'),"</a>"; ?>
                                              </div>
                                              <?php

                                            }

                                            if ($this->session->flashdata('msg_dupplicate_targetdata'))
                                            {
                                              ?>
                                              <div class="alert-danger" role="alert">
                                              <h4 class="alert-heading">Oops!</h4>
                                              <hr> 
                                              <?php echo "<a>",$this->session->flashdata('msg_dupplicate_targetdata'),"</a>"; ?>
                                              </div>
                                              <?php                                             

                                            }

                                          if ($this->session->flashdata('msg_success_targetdata'))
                                            {
                                              ?>
                                              <div class="alert-success" role="alert">
                                              <h4 class="alert-heading">Well done!</h4>
                                              <hr> 
                                              <?php echo "<a>",$this->session->flashdata('msg_success_targetdata'),"</a>"; ?>
                                              </div>
                                              <?php                                             

                                            }   
                                                
                                          if (validation_errors())
                                            {
                                                ?>
                                                <div class="alert-danger" role="alert">
                                                <h4 class="alert-heading">Oops!</h4>
                                                <hr>
                                                <?php echo validation_errors(); ?>
                                                </div>
                                                <?php
                                            }
                                        ?>
                                    </div>

                                    <?php echo form_open('TargetCon/targetdata');?>
                                    
                                        <div class="form-group" >
                                          
                                          <label for="abpYear">Year</label>
                                          <select name="abpYear" class="form-control col-3" id="abpYear" placeholder="ABP year">
                                              <option value="2017">2017</option>
                                              <option value="2018">2018</option>
                                              <option value="2019">2019</option>
                                              <option value="2020">2020</option>
                                              <option value="2021">2021</option>
                                              <option value="2022">2022</option>
                                              <option value="2023">2023</option>
                                              <option value="2024">2024</option>
                                            </select> 
                                          

                                          <label for="productID">Product Name</label>
                                          <div class="form-row">
                                            <div class="form-group">
                                                <select name="productID" id="productID" class="form-control">
                                                    <option value="">select product name</option>
                                                      <?php
                                                      foreach($product_list->result_array() as $row)
                                                          {
                                                            echo '<option value="'.$row["proID"].'">'.$row["proName"].'</option>';
                                                          }
                                                      ?>
                                                </select>
                                            </div>                                            
                                          </div>

                                          
                                          

                                          <br>

                                          <label for="productRevenue">Revenue</label>
                                          <div class="form-row">

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="productRevenueJan" class="form-control" id="productRevenueJan" placeholder="JAN">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="productRevenueFeb" class="form-control" id="productRevenueFeb" placeholder="FEB">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="productRevenueMar" class="form-control" id="productRevenueMar" placeholder="MAR">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="productRevenueApr" class="form-control" id="productRevenueApr" placeholder="APR">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="productRevenueMay" class="form-control" id="productRevenueMay" placeholder="MAY">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="productRevenueJun" class="form-control" id="productRevenueJun" placeholder="JUN">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="productRevenueJul" class="form-control" id="productRevenueJul" placeholder="JUL">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="productRevenueAug" class="form-control" id="productRevenueAug" placeholder="AUG">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="productRevenueSep" class="form-control" id="productRevenueSep" placeholder="SEP">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="productRevenueOct" class="form-control" id="productRevenueOct" placeholder="OCT">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="productRevenueNov" class="form-control" id="productRevenueNov" placeholder="NOV">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="productRevenueDec" class="form-control" id="productRevenueDec" placeholder="DEC">
                                            </div>

                                          </div>
                                          <small id="productRevenue" class="form-text text-muted">Please enter the product revenue target monthly breakdown based on annual business plan </small>

                                          <br>


                                          <label for="newConnections">New Connections</label>
                                          <div class="form-row">

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="newConnectionsJan" class="form-control" id="newConnectionsJan" placeholder="JAN">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="newConnectionsFeb" class="form-control" id="newConnectionsFeb" placeholder="FEB">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="newConnectionsMar" class="form-control" id="newConnectionsMar" placeholder="MAR">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="newConnectionsApr" class="form-control" id="newConnectionsApr" placeholder="APR">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="newConnectionsMay" class="form-control" id="newConnectionsMay" placeholder="MAY">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="newConnectionsJun" class="form-control" id="newConnectionsJun" placeholder="JUN">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="newConnectionsJul" class="form-control" id="newConnectionsJul" placeholder="JUL">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="newConnectionsAug" class="form-control" id="newConnectionsAug" placeholder="AUG">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="newConnectionsSep" class="form-control" id="newConnectionsSep" placeholder="SEP">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="newConnectionsOct" class="form-control" id="newConnectionsOct" placeholder="OCT">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="newConnectionsNov" class="form-control" id="newConnectionsNov" placeholder="NOV">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="newConnectionsDec" class="form-control" id="newConnectionsDec" placeholder="DEC">
                                            </div>

                                          </div>
                                          <small id="newConnections" class="form-text text-muted">Please enter the product new connection  target monthly breakdown based on annual business plan </small>

                                          <br>


                                          <label for="disConnections">Disconnections Forecast </label>
                                          <div class="form-row">

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="disConnectionsJan" class="form-control" id="disConnectionsJan" placeholder="JAN">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="disConnectionsFeb" class="form-control" id="disConnectionsFeb" placeholder="FEB">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="disConnectionsMar" class="form-control" id="disConnectionsMar" placeholder="MAR">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="disConnectionsApr" class="form-control" id="disConnectionsApr" placeholder="APR">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="disConnectionsMay" class="form-control" id="disConnectionsMay" placeholder="MAY">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="disConnectionsJun" class="form-control" id="disConnectionsJun" placeholder="JUN">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="disConnectionsJul" class="form-control" id="disConnectionsJul" placeholder="JUL">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="disConnectionsAug" class="form-control" id="disConnectionsAug" placeholder="AUG">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="disConnectionsSep" class="form-control" id="disConnectionsSep" placeholder="SEP">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="disConnectionsOct" class="form-control" id="disConnectionsOct" placeholder="OCT">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="disConnectionsNov" class="form-control" id="disConnectionsNov" placeholder="NOV">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="disConnectionsDec" class="form-control" id="disConnectionsDec" placeholder="DEC">
                                            </div>

                                          </div>
                                          <small id="disConnections" class="form-text text-muted">Please enter the product disconnections forecast monthly breakdown based on annual business plan </small>

                                          <br>

                                          
                                          <label for="customerBase">Customer Base</label>
                                          <input type="number" name="customerBase" class="form-control" id="customerBase" placeholder="Customer base based at the beginning of the year ">
                                      
                                        </div>

                                        <div class="raw">
                                          <button type="submit" class="btn btn-primary">submit</button> 
                                        </div>  

                                      <?php echo form_close(); ?>                                                                             
                                </div>
                            </div>
                        </div>

                        <!-- Pie Chart -->
                        <div class="col-xl-4 col-lg-5">
                            <div class="card shadow mb-4">
                                <!-- Card Header - Dropdown -->
                                <div
                                    class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-primary">Instructions</h6>
                                </div>
                                <!-- Card Body -->
                                <div class="card-body">
                                    <P class="lead text-justify" style="font-size:80%">
                                        Annual targets will not be allowed to enter 90 days prior to the relevant ABP year. This is to avoid the entering of non-finalized data into the system
                                    </P>
                                    <span style="font-size:80%">Check the available data </span>
                                    <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#targetdata">here</button>

                                    <br><br>

                                    <!-- update ABP data not implimented -->

                                    <!--<span style="font-size:80%">If you want to update existing data click</span>
                                    <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#updatetargetdata">here</button>  -->

                                </div>
                            </div>
                        </div>
                    </div>

                    
                </div>
                <!-- /.container-fluid -->

                <!-- Modal -->
                <div class="modal fade" id="targetdata" role="dialog">
                    <div class="modal-dialog">
                    
                      <!-- Modal content-->
                      <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title font-weight-bold text-primary">Available target data</h5>
                            <button type="button" class="close" data-dismiss="modal">&times;</button>  
                        </div>
                        <div class="modal-body">
                            <table border="0">  
                                <tbody>  
                                    <tr>  
                                        <td>ProID</td>
                                        <td>year</td>  
                                        <td>month</td> 
                                        <td>mRevTar</td> 
                                        <td>cxBaseTar</td>  
                                        <td>mSalesTar</td> 
                                        <td>mDisTar</td> 
                                    </tr>  
                                <?php  
                                foreach ($targetdata->result() as $row)  
                                {  
                                    ?><tr>
                                    <td><?php echo $row->proID;?></td>  
                                    <td><?php echo $row->year;?></td>  
                                    <td><?php echo $row->month;?></td>
                                    <td><?php echo $row->mRevTar;?></td>
                                    <td><?php echo $row->cxBaseTar;?></td>
                                    <td><?php echo $row->mSalesTar;?></td> 
                                    <td><?php echo $row->mDisTar;?></td> 
                                    </tr>  
                                <?php }  
                                ?>  
                                </tbody>  
                            </table>   
                        </div>

                        <div class="modal-footer">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        </div>
                      </div>
                      
                    </div>
                </div>


                <!-- update ABP data not implimented -->
                <!--<div class="modal fade" id="updatetargetdata" role="dialog">
                    <div class="modal-dialog"> -->
                    
                      <!-- Modal content-->

                      <!--<div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title font-weight-bold text-primary">Available target data</h5>
                            <button type="button" class="close" data-dismiss="modal">&times;</button>  
                        </div>
                        <div class="modal-body">
                              <?php echo form_open('TargetCon/targetupdate');?>
                                    
                                        <div class="form-group" >
                                          
                                          <label for="abpYear">Year</label>
                                          <select name="abpYear" class="form-control col-3" id="abpYear" placeholder="ABP year">
                                              <option value="2017">2017</option>
                                              <option value="2018">2018</option>
                                              <option value="2019">2019</option>
                                              <option value="2020">2020</option>
                                              <option value="2021">2021</option>
                                              <option value="2022">2022</option>
                                              <option value="2023">2023</option>
                                              <option value="2024">2024</option>
                                            </select> 
                                          

                                          <label for="productID">Product Name</label>
                                          <div class="form-row">
                                            <div class="form-group">
                                                <select name="product" id="product" class="form-control">
                                                    <option value="">select product name</option>
                                                      <?php
                                                      foreach($product_list->result_array() as $row)
                                                          {
                                                            echo '<option value="'.$row["proID"].'">'.$row["proName"].'</option>';
                                                          }
                                                      ?>
                                                </select>
                                            </div>                                            
                                          </div>

                                          
                                          

                                          <br>

                                          <label for="productRevenue">Revenue</label>
                                          <div class="form-row">

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="productRevenueJan" class="form-control" id="productRevenueJan" placeholder="JAN">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="productRevenueFeb" class="form-control" id="productRevenueFeb" placeholder="FEB">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="productRevenueMar" class="form-control" id="productRevenueMar" placeholder="MAR">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="productRevenueApr" class="form-control" id="productRevenueApr" placeholder="APR">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="productRevenueMay" class="form-control" id="productRevenueMay" placeholder="MAY">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="productRevenueJun" class="form-control" id="productRevenueJun" placeholder="JUN">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="productRevenueJul" class="form-control" id="productRevenueJul" placeholder="JUL">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="productRevenueAug" class="form-control" id="productRevenueAug" placeholder="AUG">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="productRevenueSep" class="form-control" id="productRevenueSep" placeholder="SEP">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="productRevenueOct" class="form-control" id="productRevenueOct" placeholder="OCT">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="productRevenueNov" class="form-control" id="productRevenueNov" placeholder="NOV">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="productRevenueDec" class="form-control" id="productRevenueDec" placeholder="DEC">
                                            </div>

                                          </div>
                                          <small id="productRevenue" class="form-text text-muted">Please enter the product revenue target monthly breakdown based on annual business plan </small>

                                          <br>


                                          <label for="newConnections">New Connections</label>
                                          <div class="form-row">

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="newConnectionsJan" class="form-control" id="newConnectionsJan" placeholder="JAN">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="newConnectionsFeb" class="form-control" id="newConnectionsFeb" placeholder="FEB">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="newConnectionsMar" class="form-control" id="newConnectionsMar" placeholder="MAR">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="newConnectionsApr" class="form-control" id="newConnectionsApr" placeholder="APR">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="newConnectionsMay" class="form-control" id="newConnectionsMay" placeholder="MAY">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="newConnectionsJun" class="form-control" id="newConnectionsJun" placeholder="JUN">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="newConnectionsJul" class="form-control" id="newConnectionsJul" placeholder="JUL">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="newConnectionsAug" class="form-control" id="newConnectionsAug" placeholder="AUG">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="newConnectionsSep" class="form-control" id="newConnectionsSep" placeholder="SEP">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="newConnectionsOct" class="form-control" id="newConnectionsOct" placeholder="OCT">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="newConnectionsNov" class="form-control" id="newConnectionsNov" placeholder="NOV">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="newConnectionsDec" class="form-control" id="newConnectionsDec" placeholder="DEC">
                                            </div>

                                          </div>
                                          <small id="newConnections" class="form-text text-muted">Please enter the product new connection  target monthly breakdown based on annual business plan </small>

                                          <br>


                                          <label for="disConnections">Disconnections Forecast </label>
                                          <div class="form-row">

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="disConnectionsJan" class="form-control" id="disConnectionsJan" placeholder="JAN">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="disConnectionsFeb" class="form-control" id="disConnectionsFeb" placeholder="FEB">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="disConnectionsMar" class="form-control" id="disConnectionsMar" placeholder="MAR">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="disConnectionsApr" class="form-control" id="disConnectionsApr" placeholder="APR">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="disConnectionsMay" class="form-control" id="disConnectionsMay" placeholder="MAY">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="disConnectionsJun" class="form-control" id="disConnectionsJun" placeholder="JUN">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="disConnectionsJul" class="form-control" id="disConnectionsJul" placeholder="JUL">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="disConnectionsAug" class="form-control" id="disConnectionsAug" placeholder="AUG">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="disConnectionsSep" class="form-control" id="disConnectionsSep" placeholder="SEP">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="disConnectionsOct" class="form-control" id="disConnectionsOct" placeholder="OCT">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="disConnectionsNov" class="form-control" id="disConnectionsNov" placeholder="NOV">
                                            </div>

                                            <div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-6">
                                                  <input type="number" name="disConnectionsDec" class="form-control" id="disConnectionsDec" placeholder="DEC">
                                            </div>

                                          </div>
                                          <small id="disConnections" class="form-text text-muted">Please enter the product disconnections forecast monthly breakdown based on annual business plan </small>

                                          <br>

                                          
                                          <label for="customerBase">Customer Base</label>
                                          <input type="number" name="customerBase" class="form-control" id="customerBase" placeholder="Customer base based at the beginning of the year ">
                                      
                                        </div>

                                        <div class="raw">
                                          <button type="submit" class="btn btn-primary">Update</button> 
                                        </div>  

                                      <?php echo form_close(); ?>                                                                             
                        </div>

                        <div class="modal-footer">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        </div>
                      </div> 
                      
                    </div>
                </div> -->
SS
            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; MIT-UCSC 2021</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

<?php include 'codeblocks/footer.php'?>     