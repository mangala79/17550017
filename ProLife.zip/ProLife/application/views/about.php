<?php if($this->session->userdata('admin')=='admin'){
            include 'codeblocks/adminheader.php';
        }
        else{
            include 'codeblocks/header.php';
        }
?>

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                
                <?php include 'codeblocks/topbar.php'?>
                
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">About</h1>
                    </div>

                    <!-- Content Row -->
                    <div class="row" id="Product_stages">

                        <!-- Content area - Product stages -->
                        <div class="col-xl-6 col-lg-6">
                          <div class="card shadow mb-4">
                            <!-- Card Header - Dropdown -->
                            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                              <h6 class="m-0 font-weight-bold text-primary">About ProLife System  </h6>
                            </div>
                            <!-- Card Body -->
                            <div class="card-body">
                              <P class="lead text-justify" style="font-size:80%">“ProLife” Product life cycle management system was developed as an individual project of the masters degree of Information Technology at UCSC. System is built with analytical capabilities and decision support system to interpret the outcome of the analysis.  </P>
                               <P class="lead text-justify" style="font-size:80%">System developed with very basic algorithm to demonstrate the concept and there are many venues for improvement. </P>
                               <br>
                              
                            </div>
                          </div>
                        </div>

                        <!-- Content area - Product stages -->
                        <div class="col-xl-6 col-lg-6">
                          <div class="card shadow mb-4">
                            <!-- Card Header - Dropdown -->
                            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                              <h6 class="m-0 font-weight-bold text-primary">Contact Us</h6>
                            </div>
                            <!-- Card Body -->
                            <div class="card-body">
                              <P class="lead text-justify" style="font-size:80%">
                                <div style="font-size:80%">Prolife software (Pvt) Ltd, Reid Avenue, Colombo 07</div>
                                <div style="font-size:80%">Reid Avenue, Colombo 07</div>
                                <div style="font-size:80%">Colombo 07</div>
                                <br>
                                <div style="font-size:80%">Web – WWW.prolife.lk</div>
                                <div style="font-size:80%">Email – info@prolife.lk </div>
                                <div style="font-size:80%">Tel - 0117712345</div>
                              </P>
                              
                            </div>
                          </div>
                        </div>

                    </div>


                    <div class="row" id="Product_lifecycle">

                        <!-- Content area - Product lifecycle - chart -->
                        <div class="col-xl-6 col-lg-6">
                          <div class="card shadow mb-4">
                            <!-- Card Header - Dropdown -->
                            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                              <h6 class="m-0 font-weight-bold text-primary">Product lifecycle</h6>
                            </div>
                            <!-- Card Body -->
                            <div class="card-body">
                              <img src="<?php echo base_url ('assets/img/produt_graph.png'); ?>" class="mx-auto d-block img-fluid" alt="" style="width: 600px; height: 400px;">
                              <br><br>
                              <P class="lead text-justify" style="font-size:80%">Product lifecycle is the time span from the date of the product introduction to the market and the date of product withdrawal from the market. During this time period product passes through 4 very clearly defined stages, each with its own characteristics that mean different things for business that are trying to manage the life cycle of their particular products</P>

                              <P class="lead text-justify" style="font-size:80%">Figure illustrate change of product performance parameters such as revenue, cost and profitability with time with four product lifecycle stage. Understanding on different characteristics of the each stage is essential to make the decision on product lifecycle management. </P>
                              <h5 class="text-left">Introduction</h5>
                              <P class="lead text-justify" style="font-size:80%">In this phase organization need to invest on product launch, advertising, market activations and sales campaigns. Cost of the product is very much high in this stage compared to the revenue generated by the product. This stage organization has to follow either market development strategy or market penetration strategy. This will depend on the product idea; whether it is a new product concept or existing product concept. </P>

                              <h5 class="text-left">Growth</h5>
                              <P class="lead text-justify" style="font-size:80%">The growth stage is a period of rapid market acceptance and increasing profits. In this stage number of subscribers or number of sales will be increased while improving the profits. In this stage sales need to be closely monitor against annual targets and need to take necessary corrections to avoid the gap between target and the actual performance. In growth stage we can either follow market development strategy or market penetration strategy. Early growth stage product can make losses. But, it has to made profit with in very short period. </P>

                              <h5 class="text-left">Maturity</h5>
                              <P class="lead text-justify" style="font-size:80%"> In the maturity stage, sales growth slows down because the product has achieved acceptance by most potential buyers. Profits level off or decline because marketing outlays need to be increased to defend the product against competition. Further loyalty offers, value added services, etc… need to be introduced to retain the customers without churn. </P>

                              <h5 class="text-left">Declining</h5>
                              <P class="lead text-justify" style="font-size:80%" >Finally, sales fall off and profits drop. This might due to the out dated technology or concept of the existing product. Once this indicated in the monitoring parameters, organization need to select the option such as enhance the product with new features, product rebranding, product bundling etc… to either grow or keep the existing sales or customer base. </P>

                              <br><br>

                              <P class="lead text-justify" style="font-size:80%">Life span of the product</P>

                                <img src="<?php echo base_url ('assets/img/eqn13.jpg'); ?>" class="mx-auto d-block img-fluid" alt="" style="width: 240px; height: 40px;">

                              <P class="lead text-justify" style="font-size:80%">Stages of product lifecycle</P>

                                <img src="<?php echo base_url ('assets/img/eqn14.jpg'); ?>" class="mx-auto d-block img-fluid" alt="" style="width: 360px; height: 120px;">

                                <br><br><br><br><br>
                            </div>
                          </div>
                        </div>

                        <!-- Content area - Product lifecycle -Description  -->
                        <div class="col-xl-6 col-lg-6">
                          <div class="card shadow mb-4">
                            <!-- Card Header - Dropdown -->
                            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                              <h6 class="m-0 font-weight-bold text-primary">Key Performance indicators </h6>
                            </div>
                            <!-- Card Body -->
                            <div class="card-body">


                              <P class="lead text-justify" style="font-size:80%">

                                <table style="font-size:80%">
                                  <tr>
                                    <td>AACBGPM</td>
                                    <td> - </td>
                                    <td>Aggregated Average Customer Base Growth per Month</td>
                                </tr>
                                  <tr>
                                    <td>AADPM</td>
                                    <td> - </td>
                                    <td>Aggregated Average Disconnections per Month</td>
                                  </tr>
                                  <tr>
                                    <td>AARPM</td>
                                    <td> - </td>
                                    <td>Aggregated Average Revenue per Month</td>
                                  </tr>
                                  <tr>
                                    <td>AASPM</td>
                                    <td> - </td>
                                    <td>Aggregated Average Sales per Month</td>
                                  </tr>
                                  <tr>
                                    <td>ACBAPM</td>
                                    <td> - </td>
                                    <td>Average Customer Base Growth per Month</td>
                                  </tr>
                                  <tr>
                                    <td>ADPM</td>
                                    <td> - </td>
                                    <td>Average Disconnections per Month</td>
                                  </tr>
                                  <tr>
                                    <td>ARAR</td>
                                    <td> - </td>
                                    <td>Average Revenue Achievement Rate</td>
                                  </tr>
                                  <tr>
                                    <td>ARPM</td>
                                    <td> - </td>
                                    <td>Average Revenue per Month</td>
                                  </tr>
                                  <tr>
                                    <td>ARPU</td>
                                    <td> - </td>
                                    <td>Average Revenue per User</td>
                                  </tr>
                                  <tr>
                                    <td>ASAR</td>
                                    <td> - </td>
                                    <td>Aggregated Sales Achievement Rate</td>
                                  </tr>
                                  <tr>
                                    <td>ASPM</td>
                                    <td> - </td>
                                    <td>Average Sales per Month</td>
                                  </tr>
                                  <tr>
                                    <td>CAR</td>
                                    <td> - </td>
                                    <td>Customer base Achievement Rate</td>
                                  </tr>
                                  <tr>
                                    <td>CMAR</td>
                                    <td> - </td>
                                    <td>Churn Mitigation Achievement Rate</td>
                                  </tr>
                                  <tr>
                                    <td>RAR</td>
                                    <td> - </td>
                                    <td>Revenue Achievement Rate</td>
                                  </tr>
                                  <tr>
                                    <td>SAR</td>
                                    <td> - </td>
                                    <td>Sales Achievement Rate</td>
                                  </tr>
                                  <tr>
                                    <td>Y2DAD</td>
                                    <td> - </td>
                                    <td>Year to Date Aggregated Disconnection</td>
                                  </tr>
                                  <tr>
                                    <td>Y2DAR</td>
                                    <td> - </td>
                                    <td>Year to Date Aggregated Revenue</td>
                                  </tr>
                                  <tr>
                                    <td>Y2DAS</td>
                                    <td> - </td>
                                    <td>Year to Date Aggregated Sales</td>
                                  </tr>
                                  <tr>
                                    <td>Y2DC</td>
                                    <td> - </td>
                                    <td>Year to Date Customer Base</td>
                                  </tr>
                                  <tr>
                                    <td>Y2DD</td>
                                    <td> - </td>
                                    <td>Year to Date Disconnection</td>
                                  </tr>
                                  <tr>
                                    <td>Y2DR</td>
                                    <td> - </td>
                                    <td>Y2DR Year to Date Revenue</td>
                                  </tr>
                                  <tr>
                                    <td>Y2DS</td>
                                    <td> - </td>
                                    <td>Year to Date Sales</td>
                                  </tr>
                                  <tr>
                                    <td>YOYAD</td>
                                    <td> - </td>
                                    <td>Year on Year Aggregated Disconnection</td>
                                  </tr>
                                  <tr>
                                    <td>YOYAR</td>
                                    <td> - </td>
                                    <td>Year on Year Aggregated Revenue</td>
                                  </tr>
                                  <tr>
                                    <td>YOYAS</td>
                                    <td> - </td>
                                    <td>Year on Year Aggregated Sales</td>
                                  </tr>
                                  <tr>
                                    <td>YOYC</td>
                                    <td> - </td>
                                    <td>Year on Year Customer base growth</td>
                                  </tr>
                                  <tr>
                                    <td>YOYD</td>
                                    <td> - </td>
                                    <td>Year on Year Disconnection</td>
                                  </tr>
                                  <tr>
                                    <td>YOYR</td>
                                    <td> - </td>
                                    <td>Year on Year Revenue growth</td>
                                  </tr>
                                  <tr>
                                    <td>YOYS</td>
                                    <td> - </td>
                                    <td>Year on Year Sales growth</td>
                                  </tr>

                                </table>
                                <br><br>
                                <P class="lead text-justify" style="font-size:80%">Year to Date Sales</P>

                                <img src="<?php echo base_url ('assets/img/eqn1.jpg'); ?>" class="mx-auto d-block img-fluid" alt="" style="width: 120px; height: 40px;">

                                <P class="lead text-justify" style="font-size:80%">Year to date Revenue</P>

                                <img src="<?php echo base_url ('assets/img/eqn2.jpg'); ?>" class="mx-auto d-block img-fluid" alt="" style="width: 120px; height: 40px;">

                                <P class="lead text-justify" style="font-size:80%">Year to date Customer Base</P>

                                <img src="<?php echo base_url ('assets/img/eqn3.jpg'); ?>" class="mx-auto d-block img-fluid" alt="" style="width: 120px; height: 40px;">

                                <P class="lead text-justify" style="font-size:80%">Year to date disconnections</P>

                                <img src="<?php echo base_url ('assets/img/eqn4.jpg'); ?>" class="mx-auto d-block img-fluid" alt="" style="width: 120px; height: 40px;">

                                <P class="lead text-justify" style="font-size:80%">Year on Year Sales Progress</P>

                                <img src="<?php echo base_url ('assets/img/eqn5.jpg'); ?>" class="mx-auto d-block img-fluid" alt="" style="width: 240px; height: 60px;">

                                <P class="lead text-justify" style="font-size:80%">Year on Year Revenue Growth</P>

                                <img src="<?php echo base_url ('assets/img/eqn6.jpg'); ?>" class="mx-auto d-block img-fluid" alt="" style="width: 240px; height: 60px;">

                                <P class="lead text-justify" style="font-size:80%">Year on Year Customer Base Growth</P>

                                <img src="<?php echo base_url ('assets/img/eqn7.jpg'); ?>" class="mx-auto d-block img-fluid" alt="" style="width: 240px; height: 60px;">

                                <P class="lead text-justify" style="font-size:80%">Year on Year Customer Churn mitigation</P>

                                <img src="<?php echo base_url ('assets/img/eqn8.jpg'); ?>" class="mx-auto d-block img-fluid" alt="" style="width: 240px; height: 60px;">

                                <P class="lead text-justify" style="font-size:80%">Sales success Rate</P>

                                <img src="<?php echo base_url ('assets/img/eqn9.jpg'); ?>" class="mx-auto d-block img-fluid" alt="" style="width: 120px; height: 40px;">

                                <P class="lead text-justify" style="font-size:80%">Revenue Achivement Rate</P>

                                <img src="<?php echo base_url ('assets/img/eqn10.jpg'); ?>" class="mx-auto d-block img-fluid" alt="" style="width: 120px; height: 40px;">

                                <P class="lead text-justify" style="font-size:80%">Customer base achievement rate </P>

                                <img src="<?php echo base_url ('assets/img/eqn11.jpg'); ?>" class="mx-auto d-block img-fluid" alt="" style="width: 120px; height: 40px;">

                                <P class="lead text-justify" style="font-size:80%">Churn Mitigation Achievement Rate</P>

                                <img src="<?php echo base_url ('assets/img/eqn12.jpg'); ?>" class="mx-auto d-block img-fluid" alt="" style="width: 120px; height: 40px;">

                                

                            

                              </p>

                              
                            </div>
                          </div>
                        </div>

                    </div>

                    

                    
                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; MIT-UCSC 2021</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

<?php include 'codeblocks/footer.php'?>    